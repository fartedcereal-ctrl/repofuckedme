//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VAL-R.rc

// Yeni nesneler i�in sonraki varsay�lan de�erler
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
