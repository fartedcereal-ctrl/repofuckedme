// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgGetIPLocation
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGGETIPLOCATION_HPP
#define SDK_PROTO_CGCMSGGETIPLOCATION_HPP

namespace sdk::proto {

namespace CGCMsgGetIPLocation_fields {

    constexpr int ips = 1;

} // namespace CGCMsgGetIPLocation_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGGETIPLOCATION_HPP

