// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAMAddFreeLicense
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CMSGAMADDFREELICENSE_HPP
#define SDK_PROTO_CMSGAMADDFREELICENSE_HPP

namespace sdk::proto {

namespace CMsgAMAddFreeLicense_fields {

    constexpr int steamid = 1;
    constexpr int ip_public = 2;
    constexpr int packageid = 3;
    constexpr int store_country_code = 4;

} // namespace CMsgAMAddFreeLicense_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAMADDFREELICENSE_HPP

