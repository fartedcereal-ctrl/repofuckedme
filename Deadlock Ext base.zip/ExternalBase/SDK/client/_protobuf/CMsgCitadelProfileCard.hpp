// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgCitadelProfileCard
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCITADELPROFILECARD_HPP
#define SDK_PROTO_CMSGCITADELPROFILECARD_HPP

namespace sdk::proto {

struct CMsgCitadelProfileCard_Slot;

namespace CMsgCitadelProfileCard_fields {

    enum class EStatID : int {
        k_eStat_Invalid = 0,
        k_eStat_Wins = 1,
        k_eStat_Kills = 2,
        k_eStat_GamesPlayed = 3,
    };

    namespace Slot {
        namespace Stat {
            constexpr int stat_id = 1;
            constexpr int stat_score = 2;
        } // namespace Stat

        namespace Hero {
            constexpr int hero_id = 1;
            constexpr int hero_wins = 2;
            constexpr int hero_kills = 3;
        } // namespace Hero

        constexpr int slot_id = 1;
        constexpr int stat = 2;
        constexpr int hero = 3;
    } // namespace Slot

    constexpr int account_id = 1;
    constexpr int slots = 2;
    constexpr int ranked_badge_level = 3;

} // namespace CMsgCitadelProfileCard_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCITADELPROFILECARD_HPP

