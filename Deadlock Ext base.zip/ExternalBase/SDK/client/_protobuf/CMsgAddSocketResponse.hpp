// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAddSocketResponse
// Module: client.dll
// Proto file: base_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGADDSOCKETRESPONSE_HPP
#define SDK_PROTO_CMSGADDSOCKETRESPONSE_HPP

namespace sdk::proto {

namespace CMsgAddSocketResponse_fields {

    enum class EAddSocket : int {
        k_AddSocket_Succeeded = 0,
        k_AddSocket_Failed_ToolIsInvalid = 1,
        k_AddSocket_Failed_ItemCannotBeSocketed = 2,
        k_AddSocket_Failed_FailedToAddSocket = 3,
    };

    constexpr int item_id = 1;
    constexpr int updated_socket_index = 2;
    constexpr int response = 3;

} // namespace CMsgAddSocketResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGADDSOCKETRESPONSE_HPP

