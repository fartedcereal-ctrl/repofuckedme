// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCSystemMsg_GetPurchaseTrust_Request
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCSYSTEMMSG_GETPURCHASETRUST_REQUEST_HPP
#define SDK_PROTO_CGCSYSTEMMSG_GETPURCHASETRUST_REQUEST_HPP

namespace sdk::proto {

namespace CGCSystemMsg_GetPurchaseTrust_Request_fields {

    constexpr int steamid = 1;

} // namespace CGCSystemMsg_GetPurchaseTrust_Request_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCSYSTEMMSG_GETPURCHASETRUST_REQUEST_HPP

