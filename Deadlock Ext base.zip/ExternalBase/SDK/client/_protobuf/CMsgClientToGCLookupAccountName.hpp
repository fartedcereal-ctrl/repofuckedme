// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCLookupAccountName
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCLOOKUPACCOUNTNAME_HPP
#define SDK_PROTO_CMSGCLIENTTOGCLOOKUPACCOUNTNAME_HPP

namespace sdk::proto {

namespace CMsgClientToGCLookupAccountName_fields {

    constexpr int account_id = 1;

} // namespace CMsgClientToGCLookupAccountName_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCLOOKUPACCOUNTNAME_HPP

