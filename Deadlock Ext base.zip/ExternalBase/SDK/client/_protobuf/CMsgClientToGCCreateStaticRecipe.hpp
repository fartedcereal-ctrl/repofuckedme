// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCCreateStaticRecipe
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCCREATESTATICRECIPE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCCREATESTATICRECIPE_HPP

namespace sdk::proto {

struct CMsgClientToGCCreateStaticRecipe_Item;

namespace CMsgClientToGCCreateStaticRecipe_fields {

    namespace Item {
        constexpr int item_id = 1;
        constexpr int slot_id = 2;
    } // namespace Item

    constexpr int items = 1;
    constexpr int recipe_def_index = 2;

} // namespace CMsgClientToGCCreateStaticRecipe_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCCREATESTATICRECIPE_HPP

