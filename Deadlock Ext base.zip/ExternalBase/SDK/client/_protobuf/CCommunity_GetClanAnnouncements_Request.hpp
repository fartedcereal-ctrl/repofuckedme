// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCommunity_GetClanAnnouncements_Request
// Module: client.dll
// Proto file: gcsdk_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CCOMMUNITY_GETCLANANNOUNCEMENTS_REQUEST_HPP
#define SDK_PROTO_CCOMMUNITY_GETCLANANNOUNCEMENTS_REQUEST_HPP

namespace sdk::proto {

namespace CCommunity_GetClanAnnouncements_Request_fields {

    constexpr int steamid = 1;
    constexpr int offset = 2;
    constexpr int count = 3;
    constexpr int maxchars = 4;
    constexpr int strip_html = 5;
    constexpr int required_tags = 6;
    constexpr int require_no_tags = 7;
    constexpr int language_preference = 8;
    constexpr int hidden_only = 9;
    constexpr int only_gid = 10;
    constexpr int rtime_oldest_date = 11;
    constexpr int include_hidden = 12;
    constexpr int include_partner_events = 13;

} // namespace CCommunity_GetClanAnnouncements_Request_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCOMMUNITY_GETCLANANNOUNCEMENTS_REQUEST_HPP

