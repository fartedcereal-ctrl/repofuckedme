// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetAccountStats
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTSTATS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTSTATS_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetAccountStats_fields {

    constexpr int account_id = 1;
    constexpr int dev_access_hint = 2;
    constexpr int friend_access_hint = 3;

} // namespace CMsgClientToGCGetAccountStats_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTSTATS_HPP

