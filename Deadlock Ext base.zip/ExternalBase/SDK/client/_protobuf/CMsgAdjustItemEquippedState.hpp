// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAdjustItemEquippedState
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGADJUSTITEMEQUIPPEDSTATE_HPP
#define SDK_PROTO_CMSGADJUSTITEMEQUIPPEDSTATE_HPP

namespace sdk::proto {

namespace CMsgAdjustItemEquippedState_fields {

    constexpr int item_id = 1;
    constexpr int new_class = 2;
    constexpr int new_slot = 3;
    constexpr int style_index = 4;

} // namespace CMsgAdjustItemEquippedState_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGADJUSTITEMEQUIPPEDSTATE_HPP

