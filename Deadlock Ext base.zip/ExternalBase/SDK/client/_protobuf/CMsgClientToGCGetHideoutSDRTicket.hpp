// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetHideoutSDRTicket
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETHIDEOUTSDRTICKET_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETHIDEOUTSDRTICKET_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetHideoutSDRTicket_fields {

    constexpr int lobby_id = 1;

} // namespace CMsgClientToGCGetHideoutSDRTicket_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETHIDEOUTSDRTICKET_HPP

