// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_MapPing
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_MAPPING_HPP
#define SDK_PROTO_CCITADELUSERMSG_MAPPING_HPP

namespace sdk::proto {

struct PingCommonData;

namespace CCitadelUserMsg_MapPing_fields {

    constexpr int ping_data = 1;
    constexpr int event_type = 2;
    constexpr int ping_marker_and_sound_info = 3;
    constexpr int pinged_enemy_entity = 4;
    constexpr int pinged_entity_class = 5;
    constexpr int is_minimap_ping = 6;
    constexpr int pinged_hero_name = 7;
    constexpr int is_blind_ping = 8;

} // namespace CCitadelUserMsg_MapPing_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_MAPPING_HPP

