// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_ParticipantStopSoundEvent
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSTOPSOUNDEVENT_HPP
#define SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSTOPSOUNDEVENT_HPP

namespace sdk::proto {

struct CMsgSosStopSoundEvent;

namespace CCitadelUserMsg_ParticipantStopSoundEvent_fields {

    constexpr int event = 1;
    constexpr int player_slots = 2;

} // namespace CCitadelUserMsg_ParticipantStopSoundEvent_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSTOPSOUNDEVENT_HPP

