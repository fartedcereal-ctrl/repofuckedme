// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetLeaderboard
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETLEADERBOARD_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETLEADERBOARD_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetLeaderboard_fields {

    constexpr int leaderboard_region = 1;
    constexpr int hero_id = 2;

} // namespace CMsgClientToGCGetLeaderboard_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETLEADERBOARD_HPP

