// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_CameraController
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_CAMERACONTROLLER_HPP
#define SDK_PROTO_CCITADELUSERMSG_CAMERACONTROLLER_HPP

namespace sdk::proto {

struct CCitadelUserMsg_CameraController_Approach;
struct CCitadelUserMsg_CameraController_Lag;
struct CCitadelUserMsg_CameraController_Lerp;
struct CCitadelUserMsg_CameraController_Maintain;
struct CCitadelUserMsg_CameraController_Spring;

namespace CCitadelUserMsg_CameraController_fields {

    namespace Maintain {
        constexpr int duration = 1;
    } // namespace Maintain

    namespace Approach {
        constexpr int speed = 1;
        constexpr int default_speed = 2;
        constexpr int acceleration = 3;
        constexpr int min_duration = 4;
        constexpr int approach_float = 5;
        constexpr int approach_vector = 6;
        constexpr int chase_default = 7;
    } // namespace Approach

    namespace Spring {
        constexpr int spring_strength = 1;
        constexpr int min_speed = 4;
        constexpr int max_duration = 5;
        constexpr int target_float = 6;
        constexpr int target_vector = 7;
    } // namespace Spring

    namespace Lerp {
        constexpr int start_float = 1;
        constexpr int start_vector = 2;
        constexpr int end_float = 3;
        constexpr int end_vector = 4;
        constexpr int bias = 5;
        constexpr int gain = 6;
        constexpr int duration = 7;
    } // namespace Lerp

    namespace Lag {
        constexpr int min_duration = 1;
        constexpr int lag_time = 2;
        constexpr int max_speed = 3;
        constexpr int spring_strength = 4;
        constexpr int increase_spring_strength_to_keep_target_on_screen = 5;
    } // namespace Lag

    constexpr int action = 1;
    constexpr int operation = 2;
    constexpr int param = 3;
    constexpr int param_mode = 12;
    constexpr int delay = 4;
    constexpr int relative_values = 11;
    constexpr int context_symbol_id = 5;
    constexpr int priority = 13;
    constexpr int maintain = 6;
    constexpr int approach = 7;
    constexpr int spring = 8;
    constexpr int lerp = 9;
    constexpr int lag = 10;

} // namespace CCitadelUserMsg_CameraController_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_CAMERACONTROLLER_HPP

