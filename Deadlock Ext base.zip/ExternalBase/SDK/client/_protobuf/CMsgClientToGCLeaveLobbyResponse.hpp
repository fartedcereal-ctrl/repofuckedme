// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCLeaveLobbyResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCLEAVELOBBYRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCLEAVELOBBYRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCLeaveLobbyResponse_fields {


} // namespace CMsgClientToGCLeaveLobbyResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCLEAVELOBBYRESPONSE_HPP

