// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_PlayerRespawned
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_PLAYERRESPAWNED_HPP
#define SDK_PROTO_CCITADELUSERMSG_PLAYERRESPAWNED_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_PlayerRespawned_fields {

    constexpr int player_pawn = 1;
    constexpr int facing_yaw = 2;

} // namespace CCitadelUserMsg_PlayerRespawned_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_PLAYERRESPAWNED_HPP

