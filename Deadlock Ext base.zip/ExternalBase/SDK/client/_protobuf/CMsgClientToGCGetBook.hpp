// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetBook
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETBOOK_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETBOOK_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetBook_fields {

    constexpr int book_id = 1;

} // namespace CMsgClientToGCGetBook_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETBOOK_HPP

