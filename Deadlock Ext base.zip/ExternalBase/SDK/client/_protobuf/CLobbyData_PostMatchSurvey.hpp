// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CLobbyData_PostMatchSurvey
// Module: client.dll
// Proto file: citadel_gcmessages_common.proto
#pragma once
#ifndef SDK_PROTO_CLOBBYDATA_POSTMATCHSURVEY_HPP
#define SDK_PROTO_CLOBBYDATA_POSTMATCHSURVEY_HPP

namespace sdk::proto {

struct CLobbyData_PostMatchSurvey_PlayerSurvey;

namespace CLobbyData_PostMatchSurvey_fields {

    namespace PlayerSurvey {
        constexpr int account_id = 1;
        constexpr int question_id = 2;
    } // namespace PlayerSurvey

    constexpr int surveys = 1;

} // namespace CLobbyData_PostMatchSurvey_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CLOBBYDATA_POSTMATCHSURVEY_HPP

