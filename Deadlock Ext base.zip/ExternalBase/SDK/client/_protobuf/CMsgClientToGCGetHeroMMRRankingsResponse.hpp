// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetHeroMMRRankingsResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETHEROMMRRANKINGSRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETHEROMMRRANKINGSRESPONSE_HPP

namespace sdk::proto {

struct CMsgClientToGCGetHeroMMRRankingsResponse_Hero;

namespace CMsgClientToGCGetHeroMMRRankingsResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eInvalidPermission = 1,
        k_eInternalError = 2,
        k_eTooBusy = 3,
    };

    namespace Hero {
        constexpr int hero_id = 1;
        constexpr int relative_mmr = 2;
    } // namespace Hero

    constexpr int result = 1;
    constexpr int heroes = 2;

} // namespace CMsgClientToGCGetHeroMMRRankingsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETHEROMMRRANKINGSRESPONSE_HPP

