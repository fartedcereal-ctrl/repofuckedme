// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCModeratorRequestResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCMODERATORREQUESTRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCMODERATORREQUESTRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCModeratorRequestResponse_fields {

    constexpr int success = 1;
    constexpr int response_text = 2;

} // namespace CMsgClientToGCModeratorRequestResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCMODERATORREQUESTRESPONSE_HPP

