// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCDevSetMMBias
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCDEVSETMMBIAS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCDEVSETMMBIAS_HPP

namespace sdk::proto {

namespace CMsgClientToGCDevSetMMBias_fields {

    constexpr int account_id = 1;
    constexpr int value = 2;

} // namespace CMsgClientToGCDevSetMMBias_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCDEVSETMMBIAS_HPP

