// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgApplyEggEssence
// Module: client.dll
// Proto file: base_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGAPPLYEGGESSENCE_HPP
#define SDK_PROTO_CMSGAPPLYEGGESSENCE_HPP

namespace sdk::proto {

namespace CMsgApplyEggEssence_fields {

    constexpr int essence_item_id = 1;
    constexpr int egg_item_id = 2;

} // namespace CMsgApplyEggEssence_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAPPLYEGGESSENCE_HPP

