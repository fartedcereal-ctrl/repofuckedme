// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientHello
// Module: client.dll
// Proto file: gcsdk_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTHELLO_HPP
#define SDK_PROTO_CMSGCLIENTHELLO_HPP

namespace sdk::proto {

struct CMsgSOCacheHaveVersion;

namespace CMsgClientHello_fields {

    constexpr int version = 1;
    constexpr int socache_have_versions = 2;
    constexpr int client_session_need = 3;
    constexpr int client_launcher = 4;
    constexpr int secret_key = 5;
    constexpr int client_language = 6;
    constexpr int engine = 7;
    constexpr int steamdatagram_login = 8;
    constexpr int platform_id = 9;
    constexpr int game_msg = 10;
    constexpr int os_type = 11;
    constexpr int render_system = 12;
    constexpr int render_system_req = 13;
    constexpr int screen_width = 14;
    constexpr int screen_height = 15;
    constexpr int screen_refresh = 16;
    constexpr int render_width = 17;
    constexpr int render_height = 18;
    constexpr int swap_width = 19;
    constexpr int swap_height = 20;
    constexpr int is_steam_china = 22;
    constexpr int is_steam_china_client = 24;
    constexpr int platform_name = 23;

} // namespace CMsgClientHello_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTHELLO_HPP

