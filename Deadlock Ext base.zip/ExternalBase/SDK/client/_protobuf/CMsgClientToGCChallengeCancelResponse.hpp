// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCChallengeCancelResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCCHALLENGECANCELRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCCHALLENGECANCELRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCChallengeCancelResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eInternalError = 1,
        k_eInvalidChallenge = 2,
        k_eChallengeComplete = 3,
    };

    constexpr int result = 1;

} // namespace CMsgClientToGCChallengeCancelResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCCHALLENGECANCELRESPONSE_HPP

