// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_HideoutStart
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTSTART_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTSTART_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_HideoutStart_fields {


} // namespace CCitadelClientMsg_HideoutStart_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTSTART_HPP

