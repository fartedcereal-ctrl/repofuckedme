// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetHeroChoiceResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETHEROCHOICERESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETHEROCHOICERESPONSE_HPP

namespace sdk::proto {

struct CMsgClientToGCGetHeroChoiceResponse_Hero;

namespace CMsgClientToGCGetHeroChoiceResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eNoChoices = 1,
        k_eInvalidTarget = 2,
        k_eInternalError = 3,
        k_eDisabled = 4,
        k_eTooBusy = 5,
        k_eChoiceClosed = 6,
    };

    namespace Hero {
        constexpr int hero_id = 1;
    } // namespace Hero

    constexpr int result = 1;
    constexpr int hero_selections = 2;
    constexpr int hero_choice_id = 3;
    constexpr int select_count = 4;

} // namespace CMsgClientToGCGetHeroChoiceResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETHEROCHOICERESPONSE_HPP

