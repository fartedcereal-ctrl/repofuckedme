// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_ReturnIdol
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_RETURNIDOL_HPP
#define SDK_PROTO_CCITADELUSERMSG_RETURNIDOL_HPP

namespace sdk::proto {

struct CMsgVector;

namespace CCitadelUserMsg_ReturnIdol_fields {

    constexpr int location_index = 1;
    constexpr int return_location = 2;
    constexpr int location_enabled = 3;

} // namespace CCitadelUserMsg_ReturnIdol_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_RETURNIDOL_HPP

