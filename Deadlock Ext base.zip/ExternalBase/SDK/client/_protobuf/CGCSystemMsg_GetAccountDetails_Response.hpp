// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCSystemMsg_GetAccountDetails_Response
// Module: client.dll
// Proto file: steammessages.proto
#pragma once
#ifndef SDK_PROTO_CGCSYSTEMMSG_GETACCOUNTDETAILS_RESPONSE_HPP
#define SDK_PROTO_CGCSYSTEMMSG_GETACCOUNTDETAILS_RESPONSE_HPP

namespace sdk::proto {

namespace CGCSystemMsg_GetAccountDetails_Response_fields {

    constexpr int eresult_deprecated = 1;
    constexpr int account_name = 2;
    constexpr int persona_name = 3;
    constexpr int is_profile_created = 26;
    constexpr int is_profile_public = 4;
    constexpr int is_inventory_public = 5;
    constexpr int is_vac_banned = 7;
    constexpr int is_cyber_cafe = 8;
    constexpr int is_school_account = 9;
    constexpr int is_limited = 10;
    constexpr int is_subscribed = 11;
    constexpr int package = 12;
    constexpr int is_free_trial_account = 13;
    constexpr int free_trial_expiration = 14;
    constexpr int is_low_violence = 15;
    constexpr int is_account_locked_down = 16;
    constexpr int is_community_banned = 17;
    constexpr int is_trade_banned = 18;
    constexpr int trade_ban_expiration = 19;
    constexpr int accountid = 20;
    constexpr int suspension_end_time = 21;
    constexpr int currency = 22;
    constexpr int steam_level = 23;
    constexpr int friend_count = 24;
    constexpr int account_creation_time = 25;
    constexpr int is_steamguard_enabled = 27;
    constexpr int is_phone_verified = 28;
    constexpr int is_two_factor_auth_enabled = 29;
    constexpr int two_factor_enabled_time = 30;
    constexpr int phone_verification_time = 31;
    constexpr int phone_id = 33;
    constexpr int is_phone_identifying = 34;
    constexpr int rt_identity_linked = 35;
    constexpr int rt_birth_date = 36;
    constexpr int txn_country_code = 37;
    constexpr int has_accepted_china_ssa = 38;
    constexpr int is_banned_steam_china = 39;

} // namespace CGCSystemMsg_GetAccountDetails_Response_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCSYSTEMMSG_GETACCOUNTDETAILS_RESPONSE_HPP

