// Auto-generated protobuf enums — DO NOT EDIT
// Proto file: citadel_usermessages.proto
// Module: client.dll
#pragma once
#ifndef SDK_PROTO_CITADEL_USERMESSAGES_ENUMS_HPP
#define SDK_PROTO_CITADEL_USERMESSAGES_ENUMS_HPP

namespace sdk::proto {

enum class CitadelUserMessageIds : int {
    k_EUserMsg_Damage = 300,
    k_EUserMsg_MapPing = 303,
    k_EUserMsg_TeamRewards = 304,
    k_EUserMsg_AbilityFailed = 306,
    k_EUserMsg_TriggerDamageFlash = 308,
    k_EUserMsg_AbilitiesChanged = 309,
    k_EUserMsg_RecentDamageSummary = 310,
    k_EUserMsg_SpectatorTeamChanged = 311,
    k_EUserMsg_ChatWheel = 312,
    k_EUserMsg_GoldHistory = 313,
    k_EUserMsg_ChatMsg = 314,
    k_EUserMsg_QuickResponse = 315,
    k_EUserMsg_PostMatchDetails = 316,
    k_EUserMsg_ChatEvent = 317,
    k_EUserMsg_AbilityInterrupted = 318,
    k_EUserMsg_HeroKilled = 319,
    k_EUserMsg_ReturnIdol = 320,
    k_EUserMsg_SetClientCameraAngles = 321,
    k_EUserMsg_MapLine = 322,
    k_EUserMsg_BulletHit = 323,
    k_EUserMsg_ObjectiveMask = 324,
    k_EUserMsg_ModifierApplied = 325,
    k_EUserMsg_CameraController = 326,
    k_EUserMsg_AuraModifierApplied = 327,
    k_EUserMsg_ObstructedShotFired = 329,
    k_EUserMsg_AbilityLateFailure = 330,
    k_EUserMsg_AbilityPing = 331,
    k_EUserMsg_PostProcessingAnim = 332,
    k_EUserMsg_DeathReplayData = 333,
    k_EUserMsg_PlayerLifetimeStatInfo = 334,
    k_EUserMsg_ForceShopClosed = 336,
    k_EUserMsg_StaminaConsumed = 337,
    k_EUserMsg_AbilityNotify = 338,
    k_EUserMsg_GetDamageStatsResponse = 339,
    k_EUserMsg_ParticipantStartSoundEvent = 340,
    k_EUserMsg_ParticipantStopSoundEvent = 341,
    k_EUserMsg_ParticipantStopSoundEventHash = 342,
    k_EUserMsg_ParticipantSetSoundEventParams = 343,
    k_EUserMsg_ParticipantSetLibraryStackFields = 344,
    k_EUserMsg_CurrencyChanged = 345,
    k_EUserMsg_GameOver = 346,
    k_EUserMsg_BossKilled = 347,
    k_EUserMsg_BossDamaged = 348,
    k_EUserMsg_MidBossSpawned = 349,
    k_EUserMsg_RejuvStatus = 350,
    k_EUserMsg_KillStreak = 351,
    k_EUserMsg_TeamMsg = 352,
    k_EUserMsg_PlayerRespawned = 353,
    k_EUserMsg_CallCheaterVote = 354,
    k_EUserMsg_MeleeHit = 355,
    k_EUserMsg_FlexSlotUnlocked = 356,
    k_EUserMsg_SeasonalKill = 357,
    k_EUserMsg_MusicQueue = 358,
    k_EUserMsg_AG2ParamTrigger = 359,
    k_EUserMsg_ItemPurchaseNotification = 360,
    k_EUserMsg_EntityPortalled = 361,
    k_EUserMsg_StreetBrawlScoring = 362,
    k_EUserMsg_HudGameAnnouncement = 363,
    k_EUserMsg_ItemDraftReaction = 364,
    k_EUserMsg_ImportantAbilityUsed = 365,
    k_EUserMsg_BannedHeroes = 366,
};

enum class CitadelEntityMessageIds : int {
    k_EEntityMsg_BreakablePropSpawnDebris = 500,
};

enum class ChatMsgPingMarkerInfo : int {
    k_EPingMarkerInfo_ShowMarkerAndSound = 0,
    k_EPingMarkerInfo_ShowMarkerOnSender = 1,
    k_EPingMarkerInfo_HideMarkerAndSound = 2,
    k_EPingMarkerInfo_OnlyShowMarker = 3,
    k_EPingMarkerInfo_OnlyPlaySound = 4,
    k_EPingMarkerInfo_OnlyMiniMap = 5,
};

enum class CameraOperation : int {
    k_ECameraOp_Maintain = 2,
    k_ECameraOp_Approach = 3,
    k_ECameraOp_Spring = 4,
    k_ECameraOp_Lerp = 5,
    k_ECameraOp_Lag = 6,
};

enum class CameraParam : int {
    k_EParam_ClearAllOps = 0,
    k_EParam_ClearAllOpsForContext = 1,
    k_EParam_Distance = 2,
    k_EParam_FOV = 3,
    k_EParam_TargetPosition = 4,
    k_EParam_VertOffset = 5,
    k_EParam_HorizOffset = 6,
};

enum class CameraParamMode : int {
    k_EParamMode_AllowInOneContext = 0,
    k_EParamMode_AllowInMultipleContexts = 1,
};

enum class CameraAction : int {
    k_EAction_AddOp = 0,
    k_EAction_ClearAllOps = 1,
    k_EAction_ClearOpsForContext = 2,
};

enum class ECitadelChatMessage : int {
    CITADEL_CHAT_MESSAGE_UNPAUSE_COUNTDOWN = 1,
    CITADEL_CHAT_MESSAGE_UNPAUSED = 2,
    CITADEL_CHAT_MESSAGE_AUTO_UNPAUSED = 3,
    CITADEL_CHAT_MESSAGE_PAUSE_COUNTDOWN = 4,
    CITADEL_CHAT_MESSAGE_PAUSED = 5,
    CITADEL_CHAT_MESSAGE_YOUPAUSED = 6,
    CITADEL_CHAT_MESSAGE_CANTPAUSE = 7,
    CITADEL_CHAT_MESSAGE_CANTUNPAUSETEAM = 8,
    CITADEL_CHAT_MESSAGE_NOPAUSESLEFT = 9,
    CITADEL_CHAT_MESSAGE_CANTPAUSEYET = 10,
    CITADEL_CHAT_MESSAGE_PREGAME_COUNTDOWN = 11,
    CITADEL_CHAT_MESSAGE_NOTEAMPAUSESLEFT = 12,
    CITADEL_CHAT_MESSAGE_COMMS_RESTRICTED = 13,
};

enum class PostProcessingGameStates : int {
    PostProcState_Killed = 0,
    PostProcState_Black = 1,
    PostProcState_DoormanHotelVictim = 2,
    PostProcState_Blinded = 3,
    PostProcState_DrifterDarknessCaster = 4,
    PostProcState_MatchIntro = 5,
};

} // namespace sdk::proto

#endif // SDK_PROTO_CITADEL_USERMESSAGES_ENUMS_HPP

