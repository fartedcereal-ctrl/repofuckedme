// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_GoldHistory
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_GOLDHISTORY_HPP
#define SDK_PROTO_CCITADELUSERMSG_GOLDHISTORY_HPP

namespace sdk::proto {

struct CCitadelUserMsg_GoldHistory_MinuteRecord;

namespace CCitadelUserMsg_GoldHistory_fields {

    namespace GoldRecord {
        constexpr int currency_source = 1;
        constexpr int gold = 2;
        constexpr int events = 3;
    } // namespace GoldRecord

    namespace MinuteRecord {
        constexpr int match_minute = 1;
        constexpr int gold_records = 2;
    } // namespace MinuteRecord

    constexpr int entindex_player = 1;
    constexpr int minute_records = 2;

} // namespace CCitadelUserMsg_GoldHistory_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_GOLDHISTORY_HPP

