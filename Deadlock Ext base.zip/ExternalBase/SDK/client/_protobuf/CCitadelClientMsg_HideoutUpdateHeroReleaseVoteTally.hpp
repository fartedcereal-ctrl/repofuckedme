// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_HideoutUpdateHeroReleaseVoteTally
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTUPDATEHERORELEASEVOTETALLY_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTUPDATEHERORELEASEVOTETALLY_HPP

namespace sdk::proto {

struct CCitadelClientMsg_HideoutUpdateHeroReleaseVoteTally_VoteRoundToTallyEntry;

namespace CCitadelClientMsg_HideoutUpdateHeroReleaseVoteTally_fields {

    namespace VoteRoundToTallyEntry {
        constexpr int key = 1;
        constexpr int value = 2;
    } // namespace VoteRoundToTallyEntry

    constexpr int vote_round_to_tally = 1;

} // namespace CCitadelClientMsg_HideoutUpdateHeroReleaseVoteTally_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTUPDATEHERORELEASEVOTETALLY_HPP

