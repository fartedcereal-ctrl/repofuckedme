// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAddItemToSocketData
// Module: client.dll
// Proto file: base_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGADDITEMTOSOCKETDATA_HPP
#define SDK_PROTO_CMSGADDITEMTOSOCKETDATA_HPP

namespace sdk::proto {

namespace CMsgAddItemToSocketData_fields {

    constexpr int gem_item_id = 1;
    constexpr int socket_index = 2;

} // namespace CMsgAddItemToSocketData_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGADDITEMTOSOCKETDATA_HPP

