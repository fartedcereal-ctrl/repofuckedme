// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_MidBossSpawned
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_MIDBOSSSPAWNED_HPP
#define SDK_PROTO_CCITADELUSERMSG_MIDBOSSSPAWNED_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_MidBossSpawned_fields {


} // namespace CCitadelUserMsg_MidBossSpawned_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_MIDBOSSSPAWNED_HPP

