// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCIsInMatchmakingResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCISINMATCHMAKINGRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCISINMATCHMAKINGRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCIsInMatchmakingResponse_fields {

    constexpr int in_matchmaking = 1;

} // namespace CMsgClientToGCIsInMatchmakingResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCISINMATCHMAKINGRESPONSE_HPP

