// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCBookUnlock
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCBOOKUNLOCK_HPP
#define SDK_PROTO_CMSGCLIENTTOGCBOOKUNLOCK_HPP

namespace sdk::proto {

namespace CMsgClientToGCBookUnlock_fields {

    constexpr int book_id = 1;
    constexpr int unlock_id = 2;
    constexpr int expected_cost = 3;
    constexpr int client_version = 4;

} // namespace CMsgClientToGCBookUnlock_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCBOOKUNLOCK_HPP

