// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGrantForumAccess
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGRANTFORUMACCESS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGRANTFORUMACCESS_HPP

namespace sdk::proto {

namespace CMsgClientToGCGrantForumAccess_fields {

    constexpr int email = 1;

} // namespace CMsgClientToGCGrantForumAccess_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGRANTFORUMACCESS_HPP

