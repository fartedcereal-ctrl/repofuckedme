// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_HitMismatch
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_HITMISMATCH_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_HITMISMATCH_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_HitMismatch_fields {

    constexpr int client_hit_entity_index = 1;
    constexpr int server_hit_entity_index = 2;

} // namespace CCitadelClientMsg_HitMismatch_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_HITMISMATCH_HPP

