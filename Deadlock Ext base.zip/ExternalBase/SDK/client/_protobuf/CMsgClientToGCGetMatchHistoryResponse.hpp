// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetMatchHistoryResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETMATCHHISTORYRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETMATCHHISTORYRESPONSE_HPP

namespace sdk::proto {

struct CMsgClientToGCGetMatchHistoryResponse_Match;

namespace CMsgClientToGCGetMatchHistoryResponse_fields {

    enum class EResult : int {
        k_eResult_InternalError = 0,
        k_eResult_Success = 1,
        k_eResult_InvalidPermission = 2,
        k_eResult_TemporarilyDisabled = 3,
        k_eResult_TooBusy = 4,
        k_eResult_RateLimited = 5,
    };

    namespace Match {
        constexpr int match_id = 1;
        constexpr int hero_id = 2;
        constexpr int match_duration_s = 3;
        constexpr int start_time = 4;
        constexpr int match_result = 5;
        constexpr int player_team = 6;
        constexpr int player_kills = 7;
        constexpr int player_deaths = 8;
        constexpr int player_assists = 9;
        constexpr int last_hits = 11;
        constexpr int denies = 12;
        constexpr int hero_level = 13;
        constexpr int net_worth = 14;
        constexpr int objectives_mask_team0 = 15;
        constexpr int objectives_mask_team1 = 16;
        constexpr int team_abandoned = 17;
        constexpr int abandoned_time_s = 18;
        constexpr int match_mode = 19;
        constexpr int game_mode = 20;
        constexpr int not_scored = 21;
        constexpr int game_mode_version = 22;
        constexpr int brawl_score_team0 = 23;
        constexpr int brawl_score_team1 = 24;
        constexpr int brawl_avg_round_time_s = 25;
    } // namespace Match

    constexpr int result = 1;
    constexpr int continue_cursor = 2;
    constexpr int matches = 3;

} // namespace CMsgClientToGCGetMatchHistoryResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETMATCHHISTORYRESPONSE_HPP

