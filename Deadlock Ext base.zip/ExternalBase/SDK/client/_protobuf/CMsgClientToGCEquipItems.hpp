// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCEquipItems
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCEQUIPITEMS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCEQUIPITEMS_HPP

namespace sdk::proto {

struct CMsgAdjustItemEquippedState;

namespace CMsgClientToGCEquipItems_fields {

    constexpr int equips = 1;

} // namespace CMsgClientToGCEquipItems_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCEQUIPITEMS_HPP

