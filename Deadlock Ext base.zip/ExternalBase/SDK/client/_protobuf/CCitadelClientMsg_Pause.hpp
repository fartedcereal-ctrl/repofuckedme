// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_Pause
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_PAUSE_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_PAUSE_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_Pause_fields {


} // namespace CCitadelClientMsg_Pause_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_PAUSE_HPP

