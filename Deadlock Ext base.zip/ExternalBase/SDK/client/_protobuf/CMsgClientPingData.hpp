// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientPingData
// Module: client.dll
// Proto file: base_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTPINGDATA_HPP
#define SDK_PROTO_CMSGCLIENTPINGDATA_HPP

namespace sdk::proto {

namespace CMsgClientPingData_fields {

    constexpr int relay_codes = 4;
    constexpr int relay_pings = 5;
    constexpr int region_codes = 8;
    constexpr int region_pings = 9;
    constexpr int region_ping_failed_bitmask = 10;

} // namespace CMsgClientPingData_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTPINGDATA_HPP

