// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetFriendGameStatus
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETFRIENDGAMESTATUS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETFRIENDGAMESTATUS_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetFriendGameStatus_fields {

    constexpr int include_invited = 1;

} // namespace CMsgClientToGCGetFriendGameStatus_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETFRIENDGAMESTATUS_HPP

