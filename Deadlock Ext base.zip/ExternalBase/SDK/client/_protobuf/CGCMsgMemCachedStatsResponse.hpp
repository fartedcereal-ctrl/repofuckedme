// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgMemCachedStatsResponse
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGMEMCACHEDSTATSRESPONSE_HPP
#define SDK_PROTO_CGCMSGMEMCACHEDSTATSRESPONSE_HPP

namespace sdk::proto {

namespace CGCMsgMemCachedStatsResponse_fields {

    constexpr int curr_connections = 1;
    constexpr int cmd_get = 2;
    constexpr int cmd_set = 3;
    constexpr int cmd_flush = 4;
    constexpr int get_hits = 5;
    constexpr int get_misses = 6;
    constexpr int delete_hits = 7;
    constexpr int delete_misses = 8;
    constexpr int bytes_read = 9;
    constexpr int bytes_written = 10;
    constexpr int limit_maxbytes = 11;
    constexpr int curr_items = 12;
    constexpr int evictions = 13;
    constexpr int bytes = 14;

} // namespace CGCMsgMemCachedStatsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGMEMCACHEDSTATSRESPONSE_HPP

