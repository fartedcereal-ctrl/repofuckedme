// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCSystemMsg_GetPurchaseTrust_Response
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCSYSTEMMSG_GETPURCHASETRUST_RESPONSE_HPP
#define SDK_PROTO_CGCSYSTEMMSG_GETPURCHASETRUST_RESPONSE_HPP

namespace sdk::proto {

namespace CGCSystemMsg_GetPurchaseTrust_Response_fields {

    constexpr int has_prior_purchase_history = 1;
    constexpr int has_no_recent_password_resets = 2;
    constexpr int is_wallet_cash_trusted = 3;
    constexpr int time_all_trusted = 4;

} // namespace CGCSystemMsg_GetPurchaseTrust_Response_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCSYSTEMMSG_GETPURCHASETRUST_RESPONSE_HPP

