// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgCompressedMsgToClient
// Module: client.dll
// Proto file: gcsdk_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGCOMPRESSEDMSGTOCLIENT_HPP
#define SDK_PROTO_CGCMSGCOMPRESSEDMSGTOCLIENT_HPP

namespace sdk::proto {

namespace CGCMsgCompressedMsgToClient_fields {

    constexpr int msg_id = 1;
    constexpr int compressed_msg = 2;

} // namespace CGCMsgCompressedMsgToClient_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGCOMPRESSEDMSGTOCLIENT_HPP

