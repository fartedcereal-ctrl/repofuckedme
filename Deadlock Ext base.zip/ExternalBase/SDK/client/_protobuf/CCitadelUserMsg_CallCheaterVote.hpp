// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_CallCheaterVote
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_CALLCHEATERVOTE_HPP
#define SDK_PROTO_CCITADELUSERMSG_CALLCHEATERVOTE_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_CallCheaterVote_fields {

    constexpr int player_slot = 1;

} // namespace CCitadelUserMsg_CallCheaterVote_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_CALLCHEATERVOTE_HPP

