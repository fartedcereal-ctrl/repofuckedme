// Auto-generated protobuf enums — DO NOT EDIT
// Proto file: citadel_gamemessages.proto
// Module: client.dll
#pragma once
#ifndef SDK_PROTO_CITADEL_GAMEMESSAGES_ENUMS_HPP
#define SDK_PROTO_CITADEL_GAMEMESSAGES_ENUMS_HPP

namespace sdk::proto {

enum class ECitadelGameMessages : int {
    k_EMsgGameServerToClientConnectionStatus = 10,
    k_EMsgGameServerToClientInitialGameState = 12,
    k_EMsgGameServerToClientGameCompleted = 13,
    k_EMsgGameServerToClientGoodbye = 15,
};

enum class ECitadelDisconnectReason : int {
    k_ECitadelDisconnectReason_UserLeaveMatch = 1001,
    k_ECitadelDisconnectReason_UserQuitApp = 1002,
    k_ECitadelDisconnectReason_UserCancel = 1003,
    k_ECitadelDisconnectReason_Goodbye = 1004,
    k_ECitadelDisconnectReason_BadMessage = 2001,
    k_ECitadelDisconnectReason_GameDestroyedUnexpectedly = 2002,
    k_ECitadelDisconnectReason_ChangingServer = 2003,
    k_ECitadelDisconnectReason_OldConnection = 2004,
    k_ECitadelDisconnectReason_GoodbyeUnrecognizedGame = 2005,
};

} // namespace sdk::proto

#endif // SDK_PROTO_CITADEL_GAMEMESSAGES_ENUMS_HPP

