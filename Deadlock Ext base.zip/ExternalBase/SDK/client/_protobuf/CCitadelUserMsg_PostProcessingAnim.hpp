// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_PostProcessingAnim
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_POSTPROCESSINGANIM_HPP
#define SDK_PROTO_CCITADELUSERMSG_POSTPROCESSINGANIM_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_PostProcessingAnim_fields {

    constexpr int entindex_owner = 1;
    constexpr int clear_all_states = 2;
    constexpr int state = 3;
    constexpr int delay = 4;
    constexpr int fade_in_time = 5;
    constexpr int hold_time = 6;
    constexpr int fade_out_time = 7;
    constexpr int scale = 8;

} // namespace CCitadelUserMsg_PostProcessingAnim_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_POSTPROCESSINGANIM_HPP

