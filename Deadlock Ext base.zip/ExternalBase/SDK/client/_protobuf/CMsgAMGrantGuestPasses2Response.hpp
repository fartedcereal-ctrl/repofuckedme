// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAMGrantGuestPasses2Response
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CMSGAMGRANTGUESTPASSES2RESPONSE_HPP
#define SDK_PROTO_CMSGAMGRANTGUESTPASSES2RESPONSE_HPP

namespace sdk::proto {

namespace CMsgAMGrantGuestPasses2Response_fields {

    constexpr int eresult = 1;
    constexpr int passes_granted = 2;

} // namespace CMsgAMGrantGuestPasses2Response_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAMGRANTGUESTPASSES2RESPONSE_HPP

