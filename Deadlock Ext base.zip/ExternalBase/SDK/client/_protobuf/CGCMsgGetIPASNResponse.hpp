// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgGetIPASNResponse
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGGETIPASNRESPONSE_HPP
#define SDK_PROTO_CGCMSGGETIPASNRESPONSE_HPP

namespace sdk::proto {

struct CIPASNInfo;

namespace CGCMsgGetIPASNResponse_fields {

    constexpr int infos = 1;

} // namespace CGCMsgGetIPASNResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGGETIPASNRESPONSE_HPP

