// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetActiveMatchesResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETACTIVEMATCHESRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETACTIVEMATCHESRESPONSE_HPP

namespace sdk::proto {

struct CMsgDevMatchInfo;

namespace CMsgClientToGCGetActiveMatchesResponse_fields {

    constexpr int active_matches = 1;

} // namespace CMsgClientToGCGetActiveMatchesResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETACTIVEMATCHESRESPONSE_HPP

