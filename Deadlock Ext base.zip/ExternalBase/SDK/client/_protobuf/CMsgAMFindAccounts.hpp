// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAMFindAccounts
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CMSGAMFINDACCOUNTS_HPP
#define SDK_PROTO_CMSGAMFINDACCOUNTS_HPP

namespace sdk::proto {

namespace CMsgAMFindAccounts_fields {

    constexpr int search_type = 1;
    constexpr int search_string = 2;

} // namespace CMsgAMFindAccounts_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAMFINDACCOUNTS_HPP

