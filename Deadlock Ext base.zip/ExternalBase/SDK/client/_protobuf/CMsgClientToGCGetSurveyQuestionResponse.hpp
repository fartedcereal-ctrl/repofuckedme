// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetSurveyQuestionResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETSURVEYQUESTIONRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETSURVEYQUESTIONRESPONSE_HPP

namespace sdk::proto {

struct CMsgSurveyQuestion;

namespace CMsgClientToGCGetSurveyQuestionResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eInternalError = 1,
        k_eTooBusy = 2,
    };

    constexpr int result = 1;
    constexpr int question = 2;

} // namespace CMsgClientToGCGetSurveyQuestionResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETSURVEYQUESTIONRESPONSE_HPP

