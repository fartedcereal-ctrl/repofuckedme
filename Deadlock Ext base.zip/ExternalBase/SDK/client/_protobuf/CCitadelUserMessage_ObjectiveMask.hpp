// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMessage_ObjectiveMask
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMESSAGE_OBJECTIVEMASK_HPP
#define SDK_PROTO_CCITADELUSERMESSAGE_OBJECTIVEMASK_HPP

namespace sdk::proto {

namespace CCitadelUserMessage_ObjectiveMask_fields {

    constexpr int objective_mask_team0 = 2;
    constexpr int objective_mask_team1 = 3;

} // namespace CCitadelUserMessage_ObjectiveMask_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMESSAGE_OBJECTIVEMASK_HPP

