// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCCreateStaticRecipeResponse
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCCREATESTATICRECIPERESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCCREATESTATICRECIPERESPONSE_HPP

namespace sdk::proto {

struct CMsgClientToGCCreateStaticRecipeResponse_AdditionalOutput;
struct CMsgClientToGCCreateStaticRecipeResponse_InputError;
struct CMsgClientToGCCreateStaticRecipeResponse_OutputItem;

namespace CMsgClientToGCCreateStaticRecipeResponse_fields {

    enum class EResponse : int {
        eResponse_Success = 0,
        eResponse_OfferingDisabled = 1,
        eResponse_InvalidItems = 2,
        eResponse_InternalError = 3,
        eResponse_MissingLeague = 4,
        eResponse_MissingEvent = 5,
    };

    namespace OutputItem {
        constexpr int def_index = 1;
        constexpr int item_id = 2;
        constexpr int slot_id = 3;
    } // namespace OutputItem

    namespace InputError {
        constexpr int slot_id = 1;
        constexpr int error = 2;
    } // namespace InputError

    namespace AdditionalOutput {
        constexpr int slot_id = 1;
        constexpr int value = 2;
    } // namespace AdditionalOutput

    constexpr int response = 1;
    constexpr int output_items = 2;
    constexpr int input_errors = 3;
    constexpr int additional_outputs = 4;

} // namespace CMsgClientToGCCreateStaticRecipeResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCCREATESTATICRECIPERESPONSE_HPP

