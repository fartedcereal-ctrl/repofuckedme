// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAMSendEmailResponse
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CMSGAMSENDEMAILRESPONSE_HPP
#define SDK_PROTO_CMSGAMSENDEMAILRESPONSE_HPP

namespace sdk::proto {

namespace CMsgAMSendEmailResponse_fields {

    constexpr int eresult = 1;

} // namespace CMsgAMSendEmailResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAMSENDEMAILRESPONSE_HPP

