// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAddItemToSocketResponse
// Module: client.dll
// Proto file: base_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGADDITEMTOSOCKETRESPONSE_HPP
#define SDK_PROTO_CMSGADDITEMTOSOCKETRESPONSE_HPP

namespace sdk::proto {

namespace CMsgAddItemToSocketResponse_fields {

    enum class EAddGem : int {
        k_AddGem_Succeeded = 0,
        k_AddGem_Failed_GemIsInvalid = 1,
        k_AddGem_Failed_ItemIsInvalid = 2,
        k_AddGem_Failed_FailedToAddGem = 3,
        k_AddGem_Failed_InvalidGemTypeForSocket = 4,
        k_AddGem_Failed_InvalidGemTypeForHero = 5,
        k_AddGem_Failed_InvalidGemTypeForSlot = 6,
        k_AddGem_Failed_SocketContainsUnremovableGem = 7,
    };

    constexpr int item_item_id = 1;
    constexpr int updated_socket_index = 2;
    constexpr int response = 3;

} // namespace CMsgAddItemToSocketResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGADDITEMTOSOCKETRESPONSE_HPP

