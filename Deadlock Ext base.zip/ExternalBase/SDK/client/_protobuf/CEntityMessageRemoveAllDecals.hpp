// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CEntityMessageRemoveAllDecals
// Module: client.dll
// Proto file: usermessages.proto
#pragma once
#ifndef SDK_PROTO_CENTITYMESSAGEREMOVEALLDECALS_HPP
#define SDK_PROTO_CENTITYMESSAGEREMOVEALLDECALS_HPP

namespace sdk::proto {

struct CEntityMsg;

namespace CEntityMessageRemoveAllDecals_fields {

    constexpr int remove_decals = 1;
    constexpr int entity_msg = 2;

} // namespace CEntityMessageRemoveAllDecals_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CENTITYMESSAGEREMOVEALLDECALS_HPP

