// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_PerfReport
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_PERFREPORT_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_PERFREPORT_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_PerfReport_fields {

    constexpr int average_frame_time = 1;
    constexpr int max_frame_time = 2;
    constexpr int average_compute_time = 3;
    constexpr int max_compute_time = 4;
    constexpr int average_client_tick_time = 5;
    constexpr int max_client_tick_time = 6;
    constexpr int average_client_simulate_time = 7;
    constexpr int max_client_simulate_time = 8;
    constexpr int average_output_time = 9;
    constexpr int max_output_time = 10;
    constexpr int average_wait_for_rendering_to_complete_time = 11;
    constexpr int max_wait_for_rendering_to_complete_time = 12;
    constexpr int average_swap_time = 13;
    constexpr int max_swap_time = 14;
    constexpr int average_frame_update_time = 15;
    constexpr int max_frame_update_time = 16;
    constexpr int average_idle_time = 17;
    constexpr int max_idle_time = 18;
    constexpr int average_input_processing_time = 19;
    constexpr int max_input_processing_time = 20;

} // namespace CCitadelClientMsg_PerfReport_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_PERFREPORT_HPP

