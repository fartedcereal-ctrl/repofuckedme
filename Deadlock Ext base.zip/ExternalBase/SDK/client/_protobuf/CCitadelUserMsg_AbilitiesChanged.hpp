// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_AbilitiesChanged
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_ABILITIESCHANGED_HPP
#define SDK_PROTO_CCITADELUSERMSG_ABILITIESCHANGED_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_AbilitiesChanged_fields {

    enum class Change : int {
        EInvalid = -1,
        EPurchased = 0,
        EUpgraded = 1,
        ESold = 2,
        ESwappedActivatedAbility = 3,
        EFailure = 4,
    };

    constexpr int purchaser_player_slot = 1;
    constexpr int ability_id = 2;
    constexpr int change = 3;

} // namespace CCitadelUserMsg_AbilitiesChanged_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_ABILITIESCHANGED_HPP

