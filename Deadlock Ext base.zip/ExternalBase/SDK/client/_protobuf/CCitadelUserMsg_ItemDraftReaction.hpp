// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_ItemDraftReaction
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_ITEMDRAFTREACTION_HPP
#define SDK_PROTO_CCITADELUSERMSG_ITEMDRAFTREACTION_HPP

namespace sdk::proto {

struct PingCommonData;

namespace CCitadelUserMsg_ItemDraftReaction_fields {

    constexpr int ping_data = 1;
    constexpr int rare = 2;
    constexpr int legendary = 3;

} // namespace CCitadelUserMsg_ItemDraftReaction_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_ITEMDRAFTREACTION_HPP

