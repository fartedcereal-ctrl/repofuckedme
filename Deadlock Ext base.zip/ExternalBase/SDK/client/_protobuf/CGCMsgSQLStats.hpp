// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgSQLStats
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGSQLSTATS_HPP
#define SDK_PROTO_CGCMSGSQLSTATS_HPP

namespace sdk::proto {

namespace CGCMsgSQLStats_fields {

    constexpr int schema_catalog = 1;

} // namespace CGCMsgSQLStats_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGSQLSTATS_HPP

