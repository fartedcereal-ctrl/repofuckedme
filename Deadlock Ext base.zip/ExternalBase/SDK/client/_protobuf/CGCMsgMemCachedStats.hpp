// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgMemCachedStats
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGMEMCACHEDSTATS_HPP
#define SDK_PROTO_CGCMSGMEMCACHEDSTATS_HPP

namespace sdk::proto {

namespace CGCMsgMemCachedStats_fields {


} // namespace CGCMsgMemCachedStats_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGMEMCACHEDSTATS_HPP

