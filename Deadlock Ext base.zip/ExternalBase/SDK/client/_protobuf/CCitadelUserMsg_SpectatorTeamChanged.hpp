// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_SpectatorTeamChanged
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_SPECTATORTEAMCHANGED_HPP
#define SDK_PROTO_CCITADELUSERMSG_SPECTATORTEAMCHANGED_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_SpectatorTeamChanged_fields {

    constexpr int teamnumber = 1;

} // namespace CCitadelUserMsg_SpectatorTeamChanged_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_SPECTATORTEAMCHANGED_HPP

