// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetActiveMatches
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETACTIVEMATCHES_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETACTIVEMATCHES_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetActiveMatches_fields {


} // namespace CMsgClientToGCGetActiveMatches_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETACTIVEMATCHES_HPP

