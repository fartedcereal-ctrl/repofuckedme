// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAMFindAccountsResponse
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CMSGAMFINDACCOUNTSRESPONSE_HPP
#define SDK_PROTO_CMSGAMFINDACCOUNTSRESPONSE_HPP

namespace sdk::proto {

namespace CMsgAMFindAccountsResponse_fields {

    constexpr int steam_id = 1;

} // namespace CMsgAMFindAccountsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAMFINDACCOUNTSRESPONSE_HPP

