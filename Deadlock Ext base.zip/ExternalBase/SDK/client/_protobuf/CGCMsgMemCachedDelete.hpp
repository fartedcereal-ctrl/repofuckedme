// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgMemCachedDelete
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGMEMCACHEDDELETE_HPP
#define SDK_PROTO_CGCMSGMEMCACHEDDELETE_HPP

namespace sdk::proto {

namespace CGCMsgMemCachedDelete_fields {

    constexpr int keys = 1;

} // namespace CGCMsgMemCachedDelete_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGMEMCACHEDDELETE_HPP

