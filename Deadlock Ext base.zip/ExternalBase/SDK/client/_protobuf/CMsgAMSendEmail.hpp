// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAMSendEmail
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CMSGAMSENDEMAIL_HPP
#define SDK_PROTO_CMSGAMSENDEMAIL_HPP

namespace sdk::proto {

struct CMsgAMSendEmail_PersonaNameReplacementToken;
struct CMsgAMSendEmail_ReplacementToken;

namespace CMsgAMSendEmail_fields {

    namespace ReplacementToken {
        constexpr int token_name = 1;
        constexpr int token_value = 2;
    } // namespace ReplacementToken

    namespace PersonaNameReplacementToken {
        constexpr int steamid = 1;
        constexpr int token_name = 2;
    } // namespace PersonaNameReplacementToken

    constexpr int steamid = 1;
    constexpr int email_msg_type = 2;
    constexpr int email_format = 3;
    constexpr int persona_name_tokens = 5;
    constexpr int source_gc = 6;
    constexpr int tokens = 7;

} // namespace CMsgAMSendEmail_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAMSENDEMAIL_HPP

