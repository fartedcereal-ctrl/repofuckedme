// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_ForceShopClosed
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_FORCESHOPCLOSED_HPP
#define SDK_PROTO_CCITADELUSERMSG_FORCESHOPCLOSED_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_ForceShopClosed_fields {


} // namespace CCitadelUserMsg_ForceShopClosed_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_FORCESHOPCLOSED_HPP

