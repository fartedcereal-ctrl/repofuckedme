// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCIntegrityStatus
// Module: client.dll
// Proto file: base_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCINTEGRITYSTATUS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCINTEGRITYSTATUS_HPP

namespace sdk::proto {

struct CMsgClientToGCIntegrityStatus_keyvalue;

namespace CMsgClientToGCIntegrityStatus_fields {

    namespace keyvalue {
        constexpr int id = 1;
        constexpr int extended = 2;
        constexpr int value = 3;
        constexpr int string_value = 4;
    } // namespace keyvalue

    constexpr int report = 1;
    constexpr int secure_allowed = 2;
    constexpr int diagnostics = 3;

} // namespace CMsgClientToGCIntegrityStatus_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCINTEGRITYSTATUS_HPP

