// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCChallengeActivateResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCCHALLENGEACTIVATERESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCCHALLENGEACTIVATERESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCChallengeActivateResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eInternalError = 1,
        k_eInvalidChallenge = 2,
    };

    constexpr int result = 1;

} // namespace CMsgClientToGCChallengeActivateResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCCHALLENGEACTIVATERESPONSE_HPP

