// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_HeroBuild
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_HEROBUILD_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_HEROBUILD_HPP

namespace sdk::proto {

struct CMsgHeroBuild;

namespace CCitadelClientMsg_HeroBuild_fields {

    constexpr int hero_build = 1;

} // namespace CCitadelClientMsg_HeroBuild_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_HEROBUILD_HPP

