// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CAttribute_ItemDynamicRecipeComponent
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CATTRIBUTE_ITEMDYNAMICRECIPECOMPONENT_HPP
#define SDK_PROTO_CATTRIBUTE_ITEMDYNAMICRECIPECOMPONENT_HPP

namespace sdk::proto {

namespace CAttribute_ItemDynamicRecipeComponent_fields {

    constexpr int item_def = 1;
    constexpr int item_quality = 2;
    constexpr int item_flags = 3;
    constexpr int attributes_string = 4;
    constexpr int item_count = 5;
    constexpr int items_fulfilled = 6;
    constexpr int item_rarity = 7;
    constexpr int lootlist = 8;
    constexpr int fulfilled_item_id = 9;
    constexpr int associated_item_def = 10;

} // namespace CAttribute_ItemDynamicRecipeComponent_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CATTRIBUTE_ITEMDYNAMICRECIPECOMPONENT_HPP

