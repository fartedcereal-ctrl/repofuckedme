// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAccountChallengesActive
// Module: client.dll
// Proto file: citadel_gcmessages_server.proto
#pragma once
#ifndef SDK_PROTO_CMSGACCOUNTCHALLENGESACTIVE_HPP
#define SDK_PROTO_CMSGACCOUNTCHALLENGESACTIVE_HPP

namespace sdk::proto {

struct CMsgAccountChallengesActive_Challenge;

namespace CMsgAccountChallengesActive_fields {

    namespace Challenge {
        constexpr int challenge_id = 1;
        constexpr int progress = 2;
        constexpr int max_progress = 3;
    } // namespace Challenge

    constexpr int challenges = 1;

} // namespace CMsgAccountChallengesActive_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGACCOUNTCHALLENGESACTIVE_HPP

