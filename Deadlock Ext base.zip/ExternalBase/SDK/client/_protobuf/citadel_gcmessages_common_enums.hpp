// Auto-generated protobuf enums — DO NOT EDIT
// Proto file: citadel_gcmessages_common.proto
// Module: client.dll
#pragma once
#ifndef SDK_PROTO_CITADEL_GCMESSAGES_COMMON_ENUMS_HPP
#define SDK_PROTO_CITADEL_GCMESSAGES_COMMON_ENUMS_HPP

namespace sdk::proto {

enum class CMsgLaneColor : int {
    k_ELaneColor_Invalid = 0,
    k_ELaneColor_Yellow = 1,
    k_ELaneColor_Green = 3,
    k_ELaneColor_Blue = 4,
    k_ELaneColor_Purple = 6,
};

enum class EGCCitadelCommonMessages : int {
    k_EMsgAnyToGCReportAsserts = 7000,
    k_EMsgAnyToGCReportAssertsResponse = 7001,
};

enum class ECitadelMatchMode : int {
    k_ECitadelMatchMode_Invalid = 0,
    k_ECitadelMatchMode_Unranked = 1,
    k_ECitadelMatchMode_PrivateLobby = 2,
    k_ECitadelMatchMode_CoopBot = 3,
    k_ECitadelMatchMode_Ranked = 4,
    k_ECitadelMatchMode_ServerTest = 5,
    k_ECitadelMatchMode_Tutorial = 6,
    k_ECitadelMatchMode_HeroLabs = 7,
    k_ECitadelMatchMode_Calibration = 8,
};

enum class ECitadelLobbyTeam : int {
    k_ECitadelLobbyTeam_Team0 = 0,
    k_ECitadelLobbyTeam_Team1 = 1,
    k_ECitadelLobbyTeam_Spectator = 16,
};

enum class ECitadelAccountStatMedal : int {
    k_eNone = 0,
    k_eBronze = 1,
    k_eSilver = 2,
    k_eGold = 3,
};

enum class ECitadelMMPreference : int {
    k_ECitadelMMPreference_Invalid = 0,
    k_ECitadelMMPreference_Casual = 1,
    k_ECitadelMMPreference_Serious = 2,
};

enum class ECitadelObjective : int {
    k_eCitadelObjective_Team0_Core = 0,
    k_eCitadelObjective_Team0_Tier1_Lane1 = 1,
    k_eCitadelObjective_Team0_Tier1_Lane2 = 2,
    k_eCitadelObjective_Team0_Tier1_Lane3 = 3,
    k_eCitadelObjective_Team0_Tier1_Lane4 = 4,
    k_eCitadelObjective_Team0_Tier2_Lane1 = 5,
    k_eCitadelObjective_Team0_Tier2_Lane2 = 6,
    k_eCitadelObjective_Team0_Tier2_Lane3 = 7,
    k_eCitadelObjective_Team0_Tier2_Lane4 = 8,
    k_eCitadelObjective_Team0_Titan = 9,
    k_eCitadelObjective_Team0_TitanShieldGenerator_1 = 10,
    k_eCitadelObjective_Team0_TitanShieldGenerator_2 = 11,
    k_eCitadelObjective_Team0_BarrackBoss_Lane1 = 12,
    k_eCitadelObjective_Team0_BarrackBoss_Lane2 = 13,
    k_eCitadelObjective_Team0_BarrackBoss_Lane3 = 14,
    k_eCitadelObjective_Team0_BarrackBoss_Lane4 = 15,
    k_eCitadelObjective_Team1_Core = 16,
    k_eCitadelObjective_Team1_Tier1_Lane1 = 17,
    k_eCitadelObjective_Team1_Tier1_Lane2 = 18,
    k_eCitadelObjective_Team1_Tier1_Lane3 = 19,
    k_eCitadelObjective_Team1_Tier1_Lane4 = 20,
    k_eCitadelObjective_Team1_Tier2_Lane1 = 21,
    k_eCitadelObjective_Team1_Tier2_Lane2 = 22,
    k_eCitadelObjective_Team1_Tier2_Lane3 = 23,
    k_eCitadelObjective_Team1_Tier2_Lane4 = 24,
    k_eCitadelObjective_Team1_Titan = 25,
    k_eCitadelObjective_Team1_TitanShieldGenerator_1 = 26,
    k_eCitadelObjective_Team1_TitanShieldGenerator_2 = 27,
    k_eCitadelObjective_Team1_BarrackBoss_Lane1 = 28,
    k_eCitadelObjective_Team1_BarrackBoss_Lane2 = 29,
    k_eCitadelObjective_Team1_BarrackBoss_Lane3 = 30,
    k_eCitadelObjective_Team1_BarrackBoss_Lane4 = 31,
    k_eCitadelObjective_Neutral_Mid = 32,
};

enum class ECitadelTeamObjective : int {
    k_eCitadelTeamObjective_Core = 0,
    k_eCitadelTeamObjective_Tier1_Lane1 = 1,
    k_eCitadelTeamObjective_Tier1_Lane2 = 2,
    k_eCitadelTeamObjective_Tier1_Lane3 = 3,
    k_eCitadelTeamObjective_Tier1_Lane4 = 4,
    k_eCitadelTeamObjective_Tier2_Lane1 = 5,
    k_eCitadelTeamObjective_Tier2_Lane2 = 6,
    k_eCitadelTeamObjective_Tier2_Lane3 = 7,
    k_eCitadelTeamObjective_Tier2_Lane4 = 8,
    k_eCitadelTeamObjective_Titan = 9,
    k_eCitadelTeamObjective_TitanShieldGenerator_1 = 10,
    k_eCitadelTeamObjective_TitanShieldGenerator_2 = 11,
    k_eCitadelTeamObjective_BarrackBoss_Lane1 = 12,
    k_eCitadelTeamObjective_BarrackBoss_Lane2 = 13,
    k_eCitadelTeamObjective_BarrackBoss_Lane3 = 14,
    k_eCitadelTeamObjective_BarrackBoss_Lane4 = 15,
};

enum class ECitadelBotDifficulty : int {
    k_ECitadelBotDifficulty_None = 0,
    k_ECitadelBotDifficulty_Easy = 1,
    k_ECitadelBotDifficulty_Medium = 2,
    k_ECitadelBotDifficulty_Hard = 3,
    k_ECitadelBotDifficulty_Nightmare = 4,
    k_ECitadelBotDifficulty_Guided = 5,
};

enum class ECitadelRegionMode : int {
    k_ECitadelRegionMode_ROW = 0,
    k_ECitadelRegionMode_Europe = 1,
    k_ECitadelRegionMode_SEAsia = 2,
    k_ECitadelRegionMode_SAmerica = 3,
    k_ECitadelRegionMode_Russia = 4,
    k_ECitadelRegionMode_Oceania = 5,
};

enum class ECitadelLeaderboardRegion : int {
    k_ECitadelLeaderboardRegion_None = 0,
    k_ECitadelLeaderboardRegion_Europe = 1,
    k_ECitadelLeaderboardRegion_Asia = 2,
    k_ECitadelLeaderboardRegion_NAmerica = 3,
    k_ECitadelLeaderboardRegion_SAmerica = 4,
    k_ECitadelLeaderboardRegion_Oceania = 5,
};

enum class ECitadelGameMode : int {
    k_ECitadelGameMode_Invalid = 0,
    k_ECitadelGameMode_Normal = 1,
    k_ECitadelGameMode_1v1Test = 2,
    k_ECitadelGameMode_Sandbox = 3,
    k_ECitadelGameMode_StreetBrawl = 4,
    k_ECitadelGameMode_ExploreNYC = 5,
};

enum class ELobbyServerState : int {
    k_eLobbyServerState_Assign = 0,
    k_eLobbyServerState_InGame = 1,
    k_eLobbyServerState_PostMatch = 2,
    k_eLobbyServerState_SignedOut = 3,
    k_eLobbyServerState_Abandoned = 4,
};

enum class EBannedFeature : int {
    k_eBannedFeature_Invalid = 0,
    k_eBannedFeature_LowPriorityMatchmaking = 1,
    k_eBannedFeature_CommsRestricted = 2,
    k_eBannedFeature_ReportingDisabled = 3,
};

enum class EFeatureBanReason : int {
    k_eFeatureBanReason_Invalid = 0,
    k_eFeatureBanReason_DevCommand = 1,
    k_eFeatureBanReason_ReportedByOtherPlayers = 2,
    k_eFeatureBanReason_MatchAbandons = 3,
    k_eFeatureBanReason_TooManyReportsSubmitted = 4,
};

} // namespace sdk::proto

#endif // SDK_PROTO_CITADEL_GCMESSAGES_COMMON_ENUMS_HPP

