// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetDiscordLinkResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETDISCORDLINKRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETDISCORDLINKRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetDiscordLinkResponse_fields {

    enum class EResponse : int {
        k_eInternalError = 0,
        k_eSuccess = 1,
        k_eDiscordTooBusy = 2,
        k_eAlreadyClaimed = 3,
        k_eDisabled = 4,
    };

    constexpr int response = 1;
    constexpr int discord_link = 2;
    constexpr int valid_hours = 3;

} // namespace CMsgClientToGCGetDiscordLinkResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETDISCORDLINKRESPONSE_HPP

