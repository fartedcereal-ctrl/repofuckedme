// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetLimitedItemPurchaseQuantity
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETLIMITEDITEMPURCHASEQUANTITY_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETLIMITEDITEMPURCHASEQUANTITY_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetLimitedItemPurchaseQuantity_fields {

    constexpr int item_def = 1;

} // namespace CMsgClientToGCGetLimitedItemPurchaseQuantity_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETLIMITEDITEMPURCHASEQUANTITY_HPP

