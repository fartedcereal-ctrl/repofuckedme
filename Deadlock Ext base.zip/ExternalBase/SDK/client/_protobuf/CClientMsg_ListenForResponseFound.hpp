// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CClientMsg_ListenForResponseFound
// Module: client.dll
// Proto file: clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCLIENTMSG_LISTENFORRESPONSEFOUND_HPP
#define SDK_PROTO_CCLIENTMSG_LISTENFORRESPONSEFOUND_HPP

namespace sdk::proto {

namespace CClientMsg_ListenForResponseFound_fields {

    constexpr int player_slot = 1;

} // namespace CClientMsg_ListenForResponseFound_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCLIENTMSG_LISTENFORRESPONSEFOUND_HPP

