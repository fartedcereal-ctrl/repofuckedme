// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMessage_BulletHit
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMESSAGE_BULLETHIT_HPP
#define SDK_PROTO_CCITADELUSERMESSAGE_BULLETHIT_HPP

namespace sdk::proto {

namespace CCitadelUserMessage_BulletHit_fields {

    constexpr int shotid = 1;
    constexpr int pellet = 2;
    constexpr int hit_entindex = 3;
    constexpr int weapon_entindex = 4;
    constexpr int is_predicted = 5;

} // namespace CCitadelUserMessage_BulletHit_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMESSAGE_BULLETHIT_HPP

