// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientServerHeader
// Module: client.dll
// Proto file: citadel_gamemessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTSERVERHEADER_HPP
#define SDK_PROTO_CMSGCLIENTSERVERHEADER_HPP

namespace sdk::proto {

namespace CMsgClientServerHeader_fields {

    constexpr int game_instance_id = 1;
    constexpr int local_player_index = 2;
    constexpr int payload = 3;
    constexpr int msg_id = 4;

} // namespace CMsgClientServerHeader_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTSERVERHEADER_HPP

