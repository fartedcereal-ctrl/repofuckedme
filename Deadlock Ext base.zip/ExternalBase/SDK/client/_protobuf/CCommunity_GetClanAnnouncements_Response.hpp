// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCommunity_GetClanAnnouncements_Response
// Module: client.dll
// Proto file: gcsdk_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CCOMMUNITY_GETCLANANNOUNCEMENTS_RESPONSE_HPP
#define SDK_PROTO_CCOMMUNITY_GETCLANANNOUNCEMENTS_RESPONSE_HPP

namespace sdk::proto {

struct CCommunity_ClanAnnouncementInfo;

namespace CCommunity_GetClanAnnouncements_Response_fields {

    constexpr int maxchars = 1;
    constexpr int strip_html = 2;
    constexpr int announcements = 3;

} // namespace CCommunity_GetClanAnnouncements_Response_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCOMMUNITY_GETCLANANNOUNCEMENTS_RESPONSE_HPP

