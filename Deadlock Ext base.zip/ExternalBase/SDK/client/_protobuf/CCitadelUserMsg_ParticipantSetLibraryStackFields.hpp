// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_ParticipantSetLibraryStackFields
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSETLIBRARYSTACKFIELDS_HPP
#define SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSETLIBRARYSTACKFIELDS_HPP

namespace sdk::proto {

struct CMsgSosSetLibraryStackFields;

namespace CCitadelUserMsg_ParticipantSetLibraryStackFields_fields {

    constexpr int event = 1;
    constexpr int player_slots = 2;

} // namespace CCitadelUserMsg_ParticipantSetLibraryStackFields_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSETLIBRARYSTACKFIELDS_HPP

