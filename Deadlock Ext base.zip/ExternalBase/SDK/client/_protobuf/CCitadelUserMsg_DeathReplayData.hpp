// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_DeathReplayData
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_DEATHREPLAYDATA_HPP
#define SDK_PROTO_CCITADELUSERMSG_DEATHREPLAYDATA_HPP

namespace sdk::proto {

struct CCitadelUserMsg_RecentDamageSummary;

namespace CCitadelUserMsg_DeathReplayData_fields {

    constexpr int killer_scorer = 1;
    constexpr int killer_inflictor = 2;
    constexpr int damage_summary = 3;

} // namespace CCitadelUserMsg_DeathReplayData_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_DEATHREPLAYDATA_HPP

