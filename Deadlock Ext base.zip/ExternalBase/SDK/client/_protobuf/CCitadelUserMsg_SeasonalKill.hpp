// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_SeasonalKill
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_SEASONALKILL_HPP
#define SDK_PROTO_CCITADELUSERMSG_SEASONALKILL_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_SeasonalKill_fields {

    constexpr int killer = 1;
    constexpr int victim = 2;

} // namespace CCitadelUserMsg_SeasonalKill_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_SEASONALKILL_HPP

