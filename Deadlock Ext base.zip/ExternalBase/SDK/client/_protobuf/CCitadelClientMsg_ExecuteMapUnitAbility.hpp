// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_ExecuteMapUnitAbility
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_EXECUTEMAPUNITABILITY_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_EXECUTEMAPUNITABILITY_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_ExecuteMapUnitAbility_fields {

    constexpr int ability_entity_index = 1;
    constexpr int target_entity_index = 2;

} // namespace CCitadelClientMsg_ExecuteMapUnitAbility_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_EXECUTEMAPUNITABILITY_HPP

