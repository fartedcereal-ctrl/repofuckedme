// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetAccountMatchReports
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTMATCHREPORTS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTMATCHREPORTS_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetAccountMatchReports_fields {

    constexpr int match_id = 1;

} // namespace CMsgClientToGCGetAccountMatchReports_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTMATCHREPORTS_HPP

