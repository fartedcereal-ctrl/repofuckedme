// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_StaminaConsumed
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_STAMINACONSUMED_HPP
#define SDK_PROTO_CCITADELUSERMSG_STAMINACONSUMED_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_StaminaConsumed_fields {

    constexpr int entindex_target = 1;
    constexpr int stamina_before = 3;
    constexpr int stamina_after = 4;
    constexpr int drained = 5;
    constexpr int stamina_max = 6;
    constexpr int gametime = 7;

} // namespace CCitadelUserMsg_StaminaConsumed_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_STAMINACONSUMED_HPP

