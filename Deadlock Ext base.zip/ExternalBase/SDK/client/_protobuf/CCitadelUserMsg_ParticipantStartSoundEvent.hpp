// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_ParticipantStartSoundEvent
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSTARTSOUNDEVENT_HPP
#define SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSTARTSOUNDEVENT_HPP

namespace sdk::proto {

struct CMsgSosStartSoundEvent;

namespace CCitadelUserMsg_ParticipantStartSoundEvent_fields {

    constexpr int event = 1;
    constexpr int player_slots = 2;

} // namespace CCitadelUserMsg_ParticipantStartSoundEvent_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSTARTSOUNDEVENT_HPP

