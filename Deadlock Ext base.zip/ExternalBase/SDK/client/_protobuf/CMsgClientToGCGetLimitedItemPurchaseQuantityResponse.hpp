// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetLimitedItemPurchaseQuantityResponse
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETLIMITEDITEMPURCHASEQUANTITYRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETLIMITEDITEMPURCHASEQUANTITYRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetLimitedItemPurchaseQuantityResponse_fields {

    enum class EResponse : int {
        k_eInternalError = 0,
        k_eSuccess = 1,
        k_eTooBusy = 2,
        k_eDisabled = 3,
        k_eTimeout = 4,
        k_eInvalidItemDef = 5,
        k_eItemDefNotLimited = 6,
    };

    constexpr int result = 1;
    constexpr int quantity_purchased = 2;

} // namespace CMsgClientToGCGetLimitedItemPurchaseQuantityResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETLIMITEDITEMPURCHASEQUANTITYRESPONSE_HPP

