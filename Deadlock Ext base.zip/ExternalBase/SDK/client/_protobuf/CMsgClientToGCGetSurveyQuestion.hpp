// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetSurveyQuestion
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETSURVEYQUESTION_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETSURVEYQUESTION_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetSurveyQuestion_fields {

    constexpr int dev_force_new_question_type = 1;

} // namespace CMsgClientToGCGetSurveyQuestion_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETSURVEYQUESTION_HPP

