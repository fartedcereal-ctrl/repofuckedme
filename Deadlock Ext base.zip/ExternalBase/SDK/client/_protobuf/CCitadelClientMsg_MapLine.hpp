// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_MapLine
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_MAPLINE_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_MAPLINE_HPP

namespace sdk::proto {

struct CMsgMapLine;

namespace CCitadelClientMsg_MapLine_fields {

    constexpr int mapline = 1;

} // namespace CCitadelClientMsg_MapLine_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_MAPLINE_HPP

