// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_AbilityInterrupted
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_ABILITYINTERRUPTED_HPP
#define SDK_PROTO_CCITADELUSERMSG_ABILITYINTERRUPTED_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_AbilityInterrupted_fields {

    constexpr int entindex_victim = 1;
    constexpr int entindex_interrupter = 2;
    constexpr int ability_id_interrupted = 3;
    constexpr int ability_id_interrupter = 4;
    constexpr int hero_id_interrupter = 5;

} // namespace CCitadelUserMsg_AbilityInterrupted_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_ABILITYINTERRUPTED_HPP

