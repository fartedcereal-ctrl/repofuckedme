// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_MapPing
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_MAPPING_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_MAPPING_HPP

namespace sdk::proto {

struct CMsgVector;

namespace CCitadelClientMsg_MapPing_fields {

    constexpr int ping_location = 1;
    constexpr int event_type = 2;
    constexpr int entity_index = 3;
    constexpr int is_aggressive_ping = 4;
    constexpr int is_minimap_ping = 5;
    constexpr int is_blind_ping = 6;

} // namespace CCitadelClientMsg_MapPing_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_MAPPING_HPP

