// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCModifyDevAnnouncementsResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCMODIFYDEVANNOUNCEMENTSRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCMODIFYDEVANNOUNCEMENTSRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCModifyDevAnnouncementsResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eInvalidPermission = 1,
        k_eInvalidTarget = 2,
        k_eInternalError = 3,
    };

    constexpr int result = 1;

} // namespace CMsgClientToGCModifyDevAnnouncementsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCMODIFYDEVANNOUNCEMENTSRESPONSE_HPP

