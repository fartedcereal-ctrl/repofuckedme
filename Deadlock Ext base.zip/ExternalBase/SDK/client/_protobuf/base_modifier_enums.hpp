// Auto-generated protobuf enums — DO NOT EDIT
// Proto file: base_modifier.proto
// Module: client.dll
#pragma once
#ifndef SDK_PROTO_BASE_MODIFIER_ENUMS_HPP
#define SDK_PROTO_BASE_MODIFIER_ENUMS_HPP

namespace sdk::proto {

enum class MODIFIER_ENTRY_TYPE : int {
    MODIFIER_ENTRY_TYPE_ACTIVE = 1,
    MODIFIER_ENTRY_TYPE_REMOVED = 2,
};

} // namespace sdk::proto

#endif // SDK_PROTO_BASE_MODIFIER_ENUMS_HPP

