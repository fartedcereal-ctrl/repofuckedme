// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_ChatWheel
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_CHATWHEEL_HPP
#define SDK_PROTO_CCITADELUSERMSG_CHATWHEEL_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_ChatWheel_fields {

    constexpr int chat_message_id = 1;
    constexpr int player_slot = 2;
    constexpr int pawn_entindex = 3;
    constexpr int account_id = 4;
    constexpr int hero_id = 5;
    constexpr int param_1 = 6;
    constexpr int lane_color = 7;

} // namespace CCitadelUserMsg_ChatWheel_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_CHATWHEEL_HPP

