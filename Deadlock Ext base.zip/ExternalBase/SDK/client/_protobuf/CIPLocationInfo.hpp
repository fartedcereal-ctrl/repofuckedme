// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CIPLocationInfo
// Module: client.dll
// Proto file: steammessages.proto
#pragma once
#ifndef SDK_PROTO_CIPLOCATIONINFO_HPP
#define SDK_PROTO_CIPLOCATIONINFO_HPP

namespace sdk::proto {

namespace CIPLocationInfo_fields {

    constexpr int ip = 1;
    constexpr int latitude = 2;
    constexpr int longitude = 3;
    constexpr int country = 4;
    constexpr int state = 5;
    constexpr int city = 6;

} // namespace CIPLocationInfo_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CIPLOCATIONINFO_HPP

