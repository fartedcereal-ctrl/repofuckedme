// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGenerateChallengeSet
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGENERATECHALLENGESET_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGENERATECHALLENGESET_HPP

namespace sdk::proto {

namespace CMsgClientToGCGenerateChallengeSet_fields {


} // namespace CMsgClientToGCGenerateChallengeSet_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGENERATECHALLENGESET_HPP

