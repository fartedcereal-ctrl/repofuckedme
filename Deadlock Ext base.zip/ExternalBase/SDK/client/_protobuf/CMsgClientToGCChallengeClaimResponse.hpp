// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCChallengeClaimResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCCHALLENGECLAIMRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCCHALLENGECLAIMRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCChallengeClaimResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eInternalError = 1,
        k_eInvalidChallenge = 2,
        k_eChallengeIncomplete = 3,
    };

    constexpr int result = 1;

} // namespace CMsgClientToGCChallengeClaimResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCCHALLENGECLAIMRESPONSE_HPP

