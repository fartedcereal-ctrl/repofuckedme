// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCLeaveLobby
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCLEAVELOBBY_HPP
#define SDK_PROTO_CMSGCLIENTTOGCLEAVELOBBY_HPP

namespace sdk::proto {

namespace CMsgClientToGCLeaveLobby_fields {

    constexpr int lobby_id = 1;

} // namespace CMsgClientToGCLeaveLobby_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCLEAVELOBBY_HPP

