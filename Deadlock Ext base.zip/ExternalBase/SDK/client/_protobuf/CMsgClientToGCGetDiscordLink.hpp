// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetDiscordLink
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETDISCORDLINK_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETDISCORDLINK_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetDiscordLink_fields {


} // namespace CMsgClientToGCGetDiscordLink_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETDISCORDLINK_HPP

