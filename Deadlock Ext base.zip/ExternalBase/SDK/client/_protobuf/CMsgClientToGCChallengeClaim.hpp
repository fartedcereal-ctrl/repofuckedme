// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCChallengeClaim
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCCHALLENGECLAIM_HPP
#define SDK_PROTO_CMSGCLIENTTOGCCHALLENGECLAIM_HPP

namespace sdk::proto {

namespace CMsgClientToGCChallengeClaim_fields {

    constexpr int challenge_id = 1;

} // namespace CMsgClientToGCChallengeClaim_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCCHALLENGECLAIM_HPP

