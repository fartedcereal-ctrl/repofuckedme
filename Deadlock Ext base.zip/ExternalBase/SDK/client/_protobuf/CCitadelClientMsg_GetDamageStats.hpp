// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_GetDamageStats
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_GETDAMAGESTATS_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_GETDAMAGESTATS_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_GetDamageStats_fields {

    constexpr int lobby_player_slot = 1;
    constexpr int ability_name = 2;

} // namespace CCitadelClientMsg_GetDamageStats_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_GETDAMAGESTATS_HPP

