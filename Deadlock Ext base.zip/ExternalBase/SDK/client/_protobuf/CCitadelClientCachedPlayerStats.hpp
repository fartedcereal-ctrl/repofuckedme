// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientCachedPlayerStats
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTCACHEDPLAYERSTATS_HPP
#define SDK_PROTO_CCITADELCLIENTCACHEDPLAYERSTATS_HPP

namespace sdk::proto {

struct CCitadelClientCachedPlayerStats_Stat;

namespace CCitadelClientCachedPlayerStats_fields {

    namespace Stat {
        constexpr int stat_name = 1;
        constexpr int all_time_total = 2;
        constexpr int all_time_match_max = 3;
        constexpr int all_time_life_max = 4;
    } // namespace Stat

    constexpr int version = 1;
    constexpr int stats = 2;

} // namespace CCitadelClientCachedPlayerStats_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTCACHEDPLAYERSTATS_HPP

