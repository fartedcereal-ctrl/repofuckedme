// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCDeleteHeroBuild
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCDELETEHEROBUILD_HPP
#define SDK_PROTO_CMSGCLIENTTOGCDELETEHEROBUILD_HPP

namespace sdk::proto {

namespace CMsgClientToGCDeleteHeroBuild_fields {

    constexpr int author_account_id = 1;
    constexpr int hero_build_id = 2;

} // namespace CMsgClientToGCDeleteHeroBuild_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCDELETEHEROBUILD_HPP

