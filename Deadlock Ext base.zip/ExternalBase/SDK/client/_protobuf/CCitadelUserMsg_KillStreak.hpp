// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_KillStreak
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_KILLSTREAK_HPP
#define SDK_PROTO_CCITADELUSERMSG_KILLSTREAK_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_KillStreak_fields {

    constexpr int player_pawn = 1;
    constexpr int num_kills = 2;
    constexpr int is_first_blood = 3;
    constexpr int streak_ended = 4;
    constexpr int duration = 5;

} // namespace CCitadelUserMsg_KillStreak_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_KILLSTREAK_HPP

