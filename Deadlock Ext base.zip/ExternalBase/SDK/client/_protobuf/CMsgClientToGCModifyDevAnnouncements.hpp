// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCModifyDevAnnouncements
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCMODIFYDEVANNOUNCEMENTS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCMODIFYDEVANNOUNCEMENTS_HPP

namespace sdk::proto {

namespace CMsgClientToGCModifyDevAnnouncements_fields {

    enum class EOperation : int {
        k_eCreate = 0,
        k_eUpdate = 1,
        k_eDelete = 2,
    };

    constexpr int operation = 1;
    constexpr int target_id = 2;
    constexpr int priority = 3;
    constexpr int title = 4;
    constexpr int message = 5;
    constexpr int url = 6;
    constexpr int patch_version = 7;

} // namespace CMsgClientToGCModifyDevAnnouncements_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCMODIFYDEVANNOUNCEMENTS_HPP

