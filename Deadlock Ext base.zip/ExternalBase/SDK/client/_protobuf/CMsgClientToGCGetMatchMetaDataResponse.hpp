// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetMatchMetaDataResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETMATCHMETADATARESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETMATCHMETADATARESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetMatchMetaDataResponse_fields {

    enum class EResult : int {
        k_eResult_InternalError = 0,
        k_eResult_Success = 1,
        k_eResult_InvalidPermission = 2,
        k_eResult_TemporarilyDisabled = 3,
        k_eResult_TooBusy = 4,
        k_eResult_RateLimited = 5,
        k_eResult_InvalidMatch = 6,
        k_eResult_MatchInFlight = 7,
        k_eResult_Timeout = 8,
    };

    constexpr int result = 1;
    constexpr int replay_salt = 2;
    constexpr int metadata_salt = 3;
    constexpr int replay_valid_through = 4;
    constexpr int replay_group_id = 5;
    constexpr int replay_processing_through = 6;

} // namespace CMsgClientToGCGetMatchMetaDataResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETMATCHMETADATARESPONSE_HPP

