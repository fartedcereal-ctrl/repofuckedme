// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_PostMatchDetails
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_POSTMATCHDETAILS_HPP
#define SDK_PROTO_CCITADELUSERMSG_POSTMATCHDETAILS_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_PostMatchDetails_fields {

    constexpr int match_details = 1;

} // namespace CCitadelUserMsg_PostMatchDetails_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_POSTMATCHDETAILS_HPP

