// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserCmdPB
// Module: client.dll
// Proto file: citadel_usercmd.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERCMDPB_HPP
#define SDK_PROTO_CCITADELUSERCMDPB_HPP

namespace sdk::proto {

struct CBaseUserCmdPB;
struct CMsgQAngle;
struct CMsgVector;

namespace CCitadelUserCmdPB_fields {

    constexpr int base = 1;
    constexpr int vec_camera_position = 2;
    constexpr int ang_camera_angles = 3;
    constexpr int execute_ability_indices = 4;
    constexpr int in_shop = 5;
    constexpr int camera_roaming_speed = 6;
    constexpr int using_free_cursor = 8;
    constexpr int enemy_hero_aimed_at = 10;
    constexpr int view_delta_x = 11;
    constexpr int view_delta_y = 12;
    constexpr int is_in_third_person_view = 13;

} // namespace CCitadelUserCmdPB_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERCMDPB_HPP

