// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAMGetLicenses
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CMSGAMGETLICENSES_HPP
#define SDK_PROTO_CMSGAMGETLICENSES_HPP

namespace sdk::proto {

namespace CMsgAMGetLicenses_fields {

    constexpr int steamid = 1;

} // namespace CMsgAMGetLicenses_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAMGETLICENSES_HPP

