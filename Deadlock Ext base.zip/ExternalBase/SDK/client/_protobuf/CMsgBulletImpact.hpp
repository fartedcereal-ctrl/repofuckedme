// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgBulletImpact
// Module: client.dll
// Proto file: citadel_gameevents.proto
#pragma once
#ifndef SDK_PROTO_CMSGBULLETIMPACT_HPP
#define SDK_PROTO_CMSGBULLETIMPACT_HPP

namespace sdk::proto {

struct CMsgVector;

namespace CMsgBulletImpact_fields {

    constexpr int trace_start = 1;
    constexpr int impact_origin = 2;
    constexpr int surface_normal = 3;
    constexpr int damage = 4;
    constexpr int surface_type = 5;
    constexpr int ability_ehandle = 7;
    constexpr int impacted_ehandle = 8;
    constexpr int impacted_bone_index = 9;
    constexpr int weapon_subclass_id = 10;
    constexpr int shooter_ehandle = 11;
    constexpr int bullet_radius_override = 12;

} // namespace CMsgBulletImpact_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGBULLETIMPACT_HPP

