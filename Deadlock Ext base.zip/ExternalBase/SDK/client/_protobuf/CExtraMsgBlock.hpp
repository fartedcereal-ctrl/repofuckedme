// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CExtraMsgBlock
// Module: client.dll
// Proto file: gcsdk_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CEXTRAMSGBLOCK_HPP
#define SDK_PROTO_CEXTRAMSGBLOCK_HPP

namespace sdk::proto {

namespace CExtraMsgBlock_fields {

    constexpr int msg_type = 1;
    constexpr int contents = 2;
    constexpr int msg_key = 3;
    constexpr int is_compressed = 4;

} // namespace CExtraMsgBlock_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CEXTRAMSGBLOCK_HPP

