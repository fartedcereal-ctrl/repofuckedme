// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMessage_GameOver
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMESSAGE_GAMEOVER_HPP
#define SDK_PROTO_CCITADELUSERMESSAGE_GAMEOVER_HPP

namespace sdk::proto {

namespace CCitadelUserMessage_GameOver_fields {

    constexpr int winning_team = 1;
    constexpr int just_a_test = 2;

} // namespace CCitadelUserMessage_GameOver_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMESSAGE_GAMEOVER_HPP

