// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetGiftPermissionsResponse
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETGIFTPERMISSIONSRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETGIFTPERMISSIONSRESPONSE_HPP

namespace sdk::proto {

struct CMsgClientToGCGetGiftPermissionsResponse_FriendPermission;

namespace CMsgClientToGCGetGiftPermissionsResponse_fields {

    namespace FriendPermission {
        constexpr int account_id = 1;
        constexpr int permission = 2;
    } // namespace FriendPermission

    constexpr int is_unlimited = 1;
    constexpr int has_two_factor = 3;
    constexpr int sender_permission = 6;
    constexpr int friendship_age_requirement = 7;
    constexpr int friendship_age_requirement_two_factor = 8;
    constexpr int friend_permissions = 9;

} // namespace CMsgClientToGCGetGiftPermissionsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETGIFTPERMISSIONSRESPONSE_HPP

