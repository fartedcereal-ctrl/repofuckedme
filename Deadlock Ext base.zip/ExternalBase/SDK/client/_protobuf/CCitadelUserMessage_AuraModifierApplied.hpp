// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMessage_AuraModifierApplied
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMESSAGE_AURAMODIFIERAPPLIED_HPP
#define SDK_PROTO_CCITADELUSERMESSAGE_AURAMODIFIERAPPLIED_HPP

namespace sdk::proto {

namespace CCitadelUserMessage_AuraModifierApplied_fields {

    constexpr int entindex_caster = 1;
    constexpr int entindex_target = 2;
    constexpr int modifier_type_id = 3;
    constexpr int modifier_serial_number = 4;
    constexpr int aura_start_time = 5;
    constexpr int aura_end_time = 6;

} // namespace CCitadelUserMessage_AuraModifierApplied_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMESSAGE_AURAMODIFIERAPPLIED_HPP

