// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgApplyStrangePart
// Module: client.dll
// Proto file: base_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGAPPLYSTRANGEPART_HPP
#define SDK_PROTO_CMSGAPPLYSTRANGEPART_HPP

namespace sdk::proto {

namespace CMsgApplyStrangePart_fields {

    constexpr int strange_part_item_id = 1;
    constexpr int item_item_id = 2;

} // namespace CMsgApplyStrangePart_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAPPLYSTRANGEPART_HPP

