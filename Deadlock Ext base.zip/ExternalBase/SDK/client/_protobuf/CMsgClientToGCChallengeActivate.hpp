// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCChallengeActivate
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCCHALLENGEACTIVATE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCCHALLENGEACTIVATE_HPP

namespace sdk::proto {

namespace CMsgClientToGCChallengeActivate_fields {

    constexpr int challenge_id = 1;

} // namespace CMsgClientToGCChallengeActivate_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCCHALLENGEACTIVATE_HPP

