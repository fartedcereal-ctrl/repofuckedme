// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_ChatMsg
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_CHATMSG_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_CHATMSG_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_ChatMsg_fields {

    constexpr int chat_text = 1;
    constexpr int all_chat = 2;
    constexpr int lane_color = 3;

} // namespace CCitadelClientMsg_ChatMsg_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_CHATMSG_HPP

