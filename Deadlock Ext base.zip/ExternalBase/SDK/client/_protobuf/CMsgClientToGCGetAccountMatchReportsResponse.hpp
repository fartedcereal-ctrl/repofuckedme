// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetAccountMatchReportsResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTMATCHREPORTSRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTMATCHREPORTSRESPONSE_HPP

namespace sdk::proto {

struct CMsgClientToGCGetAccountMatchReportsResponse_Commend;
struct CMsgClientToGCGetAccountMatchReportsResponse_Report;

namespace CMsgClientToGCGetAccountMatchReportsResponse_fields {

    enum class EResponse : int {
        k_eInternalError = 0,
        k_eSuccess = 1,
        k_eDisabled = 4,
        k_eTooBusy = 7,
    };

    namespace Report {
        constexpr int account_id = 1;
    } // namespace Report

    namespace Commend {
        constexpr int account_id = 1;
    } // namespace Commend

    constexpr int response = 1;
    constexpr int reports = 2;
    constexpr int commends = 3;

} // namespace CMsgClientToGCGetAccountMatchReportsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTMATCHREPORTSRESPONSE_HPP

