// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgApplyPennantUpgrade
// Module: client.dll
// Proto file: base_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGAPPLYPENNANTUPGRADE_HPP
#define SDK_PROTO_CMSGAPPLYPENNANTUPGRADE_HPP

namespace sdk::proto {

namespace CMsgApplyPennantUpgrade_fields {

    constexpr int upgrade_item_id = 1;
    constexpr int pennant_item_id = 2;

} // namespace CMsgApplyPennantUpgrade_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAPPLYPENNANTUPGRADE_HPP

