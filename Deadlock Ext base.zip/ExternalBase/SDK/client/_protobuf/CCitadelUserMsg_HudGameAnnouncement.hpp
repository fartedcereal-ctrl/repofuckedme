// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_HudGameAnnouncement
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_HUDGAMEANNOUNCEMENT_HPP
#define SDK_PROTO_CCITADELUSERMSG_HUDGAMEANNOUNCEMENT_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_HudGameAnnouncement_fields {

    constexpr int title_locstring = 1;
    constexpr int description_locstring = 2;
    constexpr int classname = 3;
    constexpr int dialog_variable_name = 4;
    constexpr int dialog_variable_locstring = 5;

} // namespace CCitadelUserMsg_HudGameAnnouncement_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_HUDGAMEANNOUNCEMENT_HPP

