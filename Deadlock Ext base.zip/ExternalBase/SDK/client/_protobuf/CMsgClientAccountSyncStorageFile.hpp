// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientAccountSyncStorageFile
// Module: client.dll
// Proto file: citadel_gamemessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTACCOUNTSYNCSTORAGEFILE_HPP
#define SDK_PROTO_CMSGCLIENTACCOUNTSYNCSTORAGEFILE_HPP

namespace sdk::proto {

namespace CMsgClientAccountSyncStorageFile_fields {

    constexpr int version = 1;
    constexpr int ids = 2;
    constexpr int values = 3;

} // namespace CMsgClientAccountSyncStorageFile_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTACCOUNTSYNCSTORAGEFILE_HPP

