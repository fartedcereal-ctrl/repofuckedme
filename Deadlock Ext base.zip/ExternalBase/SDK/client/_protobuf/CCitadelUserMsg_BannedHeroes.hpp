// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_BannedHeroes
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_BANNEDHEROES_HPP
#define SDK_PROTO_CCITADELUSERMSG_BANNEDHEROES_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_BannedHeroes_fields {

    constexpr int banned_hero_ids = 1;

} // namespace CCitadelUserMsg_BannedHeroes_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_BANNEDHEROES_HPP

