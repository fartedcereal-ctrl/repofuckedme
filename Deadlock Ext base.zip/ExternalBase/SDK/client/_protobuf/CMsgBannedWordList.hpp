// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgBannedWordList
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGBANNEDWORDLIST_HPP
#define SDK_PROTO_CMSGBANNEDWORDLIST_HPP

namespace sdk::proto {

namespace CMsgBannedWordList_fields {

    constexpr int version = 1;
    constexpr int banned_words = 2;

} // namespace CMsgBannedWordList_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGBANNEDWORDLIST_HPP

