// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CIPASNInfo
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CIPASNINFO_HPP
#define SDK_PROTO_CIPASNINFO_HPP

namespace sdk::proto {

namespace CIPASNInfo_fields {

    constexpr int ip = 1;
    constexpr int asn = 2;

} // namespace CIPASNInfo_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CIPASNINFO_HPP

