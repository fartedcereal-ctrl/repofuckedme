// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMessage_AbilityNotify
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMESSAGE_ABILITYNOTIFY_HPP
#define SDK_PROTO_CCITADELUSERMESSAGE_ABILITYNOTIFY_HPP

namespace sdk::proto {

namespace CCitadelUserMessage_AbilityNotify_fields {

    constexpr int entindex_victim = 1;
    constexpr int entindex_attacker = 2;
    constexpr int ability_id = 3;
    constexpr int status_impact = 4;

} // namespace CCitadelUserMessage_AbilityNotify_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMESSAGE_ABILITYNOTIFY_HPP

