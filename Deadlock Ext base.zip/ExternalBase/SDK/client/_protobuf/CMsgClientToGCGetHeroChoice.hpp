// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetHeroChoice
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETHEROCHOICE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETHEROCHOICE_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetHeroChoice_fields {


} // namespace CMsgClientToGCGetHeroChoice_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETHEROCHOICE_HPP

