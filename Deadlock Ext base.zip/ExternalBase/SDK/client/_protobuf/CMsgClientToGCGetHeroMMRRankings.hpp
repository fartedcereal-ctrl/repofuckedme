// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetHeroMMRRankings
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETHEROMMRRANKINGS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETHEROMMRRANKINGS_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetHeroMMRRankings_fields {

    constexpr int target_account_id = 1;

} // namespace CMsgClientToGCGetHeroMMRRankings_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETHEROMMRRANKINGS_HPP

