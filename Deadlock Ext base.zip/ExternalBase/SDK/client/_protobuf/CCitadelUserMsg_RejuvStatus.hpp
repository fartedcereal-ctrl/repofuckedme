// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_RejuvStatus
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_REJUVSTATUS_HPP
#define SDK_PROTO_CCITADELUSERMSG_REJUVSTATUS_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_RejuvStatus_fields {

    constexpr int killing_team = 1;
    constexpr int player_pawn = 2;
    constexpr int user_team = 3;
    constexpr int event_type = 4;

} // namespace CCitadelUserMsg_RejuvStatus_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_REJUVSTATUS_HPP

