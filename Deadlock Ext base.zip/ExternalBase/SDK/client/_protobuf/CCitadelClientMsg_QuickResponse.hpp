// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_QuickResponse
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_QUICKRESPONSE_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_QUICKRESPONSE_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_QuickResponse_fields {

    constexpr int ping_wheel_message_id = 1;
    constexpr int responding_to_ping_message_id = 2;
    constexpr int responding_to_player_slot = 3;

} // namespace CCitadelClientMsg_QuickResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_QUICKRESPONSE_HPP

