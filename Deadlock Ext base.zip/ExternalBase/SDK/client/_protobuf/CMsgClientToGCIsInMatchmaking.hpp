// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCIsInMatchmaking
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCISINMATCHMAKING_HPP
#define SDK_PROTO_CMSGCLIENTTOGCISINMATCHMAKING_HPP

namespace sdk::proto {

namespace CMsgClientToGCIsInMatchmaking_fields {


} // namespace CMsgClientToGCIsInMatchmaking_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCISINMATCHMAKING_HPP

