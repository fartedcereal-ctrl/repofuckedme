// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCToGCMsgMasterStartupComplete
// Module: client.dll
// Proto file: gcsdk_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CGCTOGCMSGMASTERSTARTUPCOMPLETE_HPP
#define SDK_PROTO_CGCTOGCMSGMASTERSTARTUPCOMPLETE_HPP

namespace sdk::proto {

struct CGCToGCMsgMasterStartupComplete_GCInfo;

namespace CGCToGCMsgMasterStartupComplete_fields {

    namespace GCInfo {
        constexpr int dir_index = 1;
        constexpr int machine_name = 2;
    } // namespace GCInfo

    constexpr int gc_info = 1;

} // namespace CGCToGCMsgMasterStartupComplete_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCTOGCMSGMASTERSTARTUPCOMPLETE_HPP

