// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_MusicQueue
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_MUSICQUEUE_HPP
#define SDK_PROTO_CCITADELUSERMSG_MUSICQUEUE_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_MusicQueue_fields {

    constexpr int music_state = 1;
    constexpr int override = 2;

} // namespace CCitadelUserMsg_MusicQueue_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_MUSICQUEUE_HPP

