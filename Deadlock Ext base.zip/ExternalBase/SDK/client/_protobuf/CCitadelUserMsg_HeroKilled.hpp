// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_HeroKilled
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_HEROKILLED_HPP
#define SDK_PROTO_CCITADELUSERMSG_HEROKILLED_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_HeroKilled_fields {

    constexpr int entindex_victim = 1;
    constexpr int entindex_inflictor = 2;
    constexpr int entindex_attacker = 3;
    constexpr int entindex_assisters = 4;
    constexpr int entindex_scorer = 5;
    constexpr int respawn_reason = 6;
    constexpr int victim_team_number = 7;

} // namespace CCitadelUserMsg_HeroKilled_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_HEROKILLED_HPP

