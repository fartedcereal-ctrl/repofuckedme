// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAnyToGCReportAsserts
// Module: client.dll
// Proto file: citadel_gcmessages_common.proto
#pragma once
#ifndef SDK_PROTO_CMSGANYTOGCREPORTASSERTS_HPP
#define SDK_PROTO_CMSGANYTOGCREPORTASSERTS_HPP

namespace sdk::proto {

struct CMsgAnyToGCReportAsserts_TrackedAssert;

namespace CMsgAnyToGCReportAsserts_fields {

    namespace TrackedAssert {
        constexpr int filename = 1;
        constexpr int line_number = 2;
        constexpr int sample_msg = 3;
        constexpr int sample_stack = 4;
        constexpr int times_fired = 5;
        constexpr int function_name = 6;
        constexpr int condition = 7;
        constexpr int total_times_fired = 8;
    } // namespace TrackedAssert

    constexpr int version = 1;
    constexpr int asserts = 2;
    constexpr int match_id = 3;

} // namespace CMsgAnyToGCReportAsserts_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGANYTOGCREPORTASSERTS_HPP

