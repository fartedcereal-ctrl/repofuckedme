// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_AbilityPing
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_ABILITYPING_HPP
#define SDK_PROTO_CCITADELUSERMSG_ABILITYPING_HPP

namespace sdk::proto {

struct PingCommonData;

namespace CCitadelUserMsg_AbilityPing_fields {

    constexpr int ping_data = 1;
    constexpr int ability_id = 2;
    constexpr int ability_cooldown = 3;
    constexpr int ping_marker_and_sound_info = 4;

} // namespace CCitadelUserMsg_AbilityPing_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_ABILITYPING_HPP

