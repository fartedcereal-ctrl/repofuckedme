// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_HideoutMenuState
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTMENUSTATE_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTMENUSTATE_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_HideoutMenuState_fields {

    enum class MenuState : int {
        k_eNone = 0,
        k_eEscapeMenu = 1,
        k_eDashboard = 2,
    };

    constexpr int menu_state = 1;

} // namespace CCitadelClientMsg_HideoutMenuState_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTMENUSTATE_HPP

