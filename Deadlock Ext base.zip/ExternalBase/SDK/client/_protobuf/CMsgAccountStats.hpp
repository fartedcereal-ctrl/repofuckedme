// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAccountStats
// Module: client.dll
// Proto file: citadel_gcmessages_common.proto
#pragma once
#ifndef SDK_PROTO_CMSGACCOUNTSTATS_HPP
#define SDK_PROTO_CMSGACCOUNTSTATS_HPP

namespace sdk::proto {

struct CMsgAccountHeroStats;

namespace CMsgAccountStats_fields {

    constexpr int account_id = 1;
    constexpr int stats = 2;

} // namespace CMsgAccountStats_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGACCOUNTSTATS_HPP

