// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_QuickResponse
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_QUICKRESPONSE_HPP
#define SDK_PROTO_CCITADELUSERMSG_QUICKRESPONSE_HPP

namespace sdk::proto {

struct PingCommonData;

namespace CCitadelUserMsg_QuickResponse_fields {

    constexpr int ping_data = 1;
    constexpr int responding_to_ping_message_id = 2;
    constexpr int responding_to_player_slot = 3;
    constexpr int lane_color = 4;

} // namespace CCitadelUserMsg_QuickResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_QUICKRESPONSE_HPP

