// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgGetIPLocationResponse
// Module: client.dll
// Proto file: steammessages.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGGETIPLOCATIONRESPONSE_HPP
#define SDK_PROTO_CGCMSGGETIPLOCATIONRESPONSE_HPP

namespace sdk::proto {

struct CIPLocationInfo;

namespace CGCMsgGetIPLocationResponse_fields {

    constexpr int infos = 1;

} // namespace CGCMsgGetIPLocationResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGGETIPLOCATIONRESPONSE_HPP

