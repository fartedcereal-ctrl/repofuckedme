// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMessage_ImportantAbilityUsed
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMESSAGE_IMPORTANTABILITYUSED_HPP
#define SDK_PROTO_CCITADELUSERMESSAGE_IMPORTANTABILITYUSED_HPP

namespace sdk::proto {

namespace CCitadelUserMessage_ImportantAbilityUsed_fields {

    constexpr int player = 1;
    constexpr int caster = 2;
    constexpr int ability_name = 3;

} // namespace CCitadelUserMessage_ImportantAbilityUsed_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMESSAGE_IMPORTANTABILITYUSED_HPP

