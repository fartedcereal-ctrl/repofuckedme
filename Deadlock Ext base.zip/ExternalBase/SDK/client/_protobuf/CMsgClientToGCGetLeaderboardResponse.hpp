// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetLeaderboardResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETLEADERBOARDRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETLEADERBOARDRESPONSE_HPP

namespace sdk::proto {

struct CMsgClientToGCGetLeaderboardResponse_LeaderboardEntry;

namespace CMsgClientToGCGetLeaderboardResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eInvalidArguments = 1,
        k_eInternalError = 2,
        k_eTooBusy = 3,
    };

    namespace LeaderboardEntry {
        constexpr int account_name = 1;
        constexpr int rank = 2;
        constexpr int top_hero_ids = 3;
        constexpr int badge_level = 4;
    } // namespace LeaderboardEntry

    constexpr int result = 1;
    constexpr int entries = 2;
    constexpr int local_player_index = 3;

} // namespace CMsgClientToGCGetLeaderboardResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETLEADERBOARDRESPONSE_HPP

