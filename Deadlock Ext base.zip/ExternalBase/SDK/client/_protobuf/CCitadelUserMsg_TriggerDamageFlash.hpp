// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_TriggerDamageFlash
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_TRIGGERDAMAGEFLASH_HPP
#define SDK_PROTO_CCITADELUSERMSG_TRIGGERDAMAGEFLASH_HPP

namespace sdk::proto {

struct CMsgVector;

namespace CCitadelUserMsg_TriggerDamageFlash_fields {

    constexpr int entindex_flash_victim = 1;
    constexpr int entindex_flash_attacker = 2;
    constexpr int entindex_flash_hitgroup = 3;
    constexpr int flash_value = 4;
    constexpr int flash_type = 5;
    constexpr int flash_flags = 6;
    constexpr int flash_position = 7;

} // namespace CCitadelUserMsg_TriggerDamageFlash_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_TRIGGERDAMAGEFLASH_HPP

