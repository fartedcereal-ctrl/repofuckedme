// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCCancelUnfinalizedTransactions
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCCANCELUNFINALIZEDTRANSACTIONS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCCANCELUNFINALIZEDTRANSACTIONS_HPP

namespace sdk::proto {

namespace CMsgClientToGCCancelUnfinalizedTransactions_fields {

    constexpr int unused = 1;

} // namespace CMsgClientToGCCancelUnfinalizedTransactions_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCCANCELUNFINALIZEDTRANSACTIONS_HPP

