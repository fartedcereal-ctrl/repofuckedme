// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgMemCachedSet
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGMEMCACHEDSET_HPP
#define SDK_PROTO_CGCMSGMEMCACHEDSET_HPP

namespace sdk::proto {

struct CGCMsgMemCachedSet_KeyPair;

namespace CGCMsgMemCachedSet_fields {

    namespace KeyPair {
        constexpr int name = 1;
        constexpr int value = 2;
    } // namespace KeyPair

    constexpr int keys = 1;

} // namespace CGCMsgMemCachedSet_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGMEMCACHEDSET_HPP

