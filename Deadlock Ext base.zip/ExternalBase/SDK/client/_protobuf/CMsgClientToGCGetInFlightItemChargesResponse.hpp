// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetInFlightItemChargesResponse
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETINFLIGHTITEMCHARGESRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETINFLIGHTITEMCHARGESRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetInFlightItemChargesResponse_fields {

    enum class EResponse : int {
        k_eInternalError = 0,
        k_eSuccess = 1,
        k_eTooBusy = 2,
        k_eDisabled = 3,
        k_eTimeout = 4,
        k_eInvalidItemDef = 5,
    };

    constexpr int result = 1;
    constexpr int charges_in_flight = 2;

} // namespace CMsgClientToGCGetInFlightItemChargesResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETINFLIGHTITEMCHARGESRESPONSE_HPP

