// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_BossKilled
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_BOSSKILLED_HPP
#define SDK_PROTO_CCITADELUSERMSG_BOSSKILLED_HPP

namespace sdk::proto {

struct CMsgVector;

namespace CCitadelUserMsg_BossKilled_fields {

    constexpr int objective_team = 1;
    constexpr int objective_mask_change = 2;
    constexpr int entity_killed = 3;
    constexpr int entity_killed_class = 4;
    constexpr int entity_killer = 5;
    constexpr int gametime = 6;
    constexpr int bosses_remaining = 7;
    constexpr int entity_position = 8;

} // namespace CCitadelUserMsg_BossKilled_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_BOSSKILLED_HPP

