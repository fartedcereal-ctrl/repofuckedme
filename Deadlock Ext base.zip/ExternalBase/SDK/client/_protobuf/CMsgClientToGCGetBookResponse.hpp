// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetBookResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETBOOKRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETBOOKRESPONSE_HPP

namespace sdk::proto {

struct CMsgAccountBook;

namespace CMsgClientToGCGetBookResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eInternalError = 1,
        k_eInvalidBook = 2,
        k_eDisabled = 3,
        k_eTooBusy = 4,
    };

    constexpr int result = 1;
    constexpr int book = 2;

} // namespace CMsgClientToGCGetBookResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETBOOKRESPONSE_HPP

