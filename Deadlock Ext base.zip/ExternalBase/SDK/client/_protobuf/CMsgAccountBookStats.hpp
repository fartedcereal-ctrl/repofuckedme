// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAccountBookStats
// Module: client.dll
// Proto file: citadel_gcmessages_common.proto
#pragma once
#ifndef SDK_PROTO_CMSGACCOUNTBOOKSTATS_HPP
#define SDK_PROTO_CMSGACCOUNTBOOKSTATS_HPP

namespace sdk::proto {

namespace CMsgAccountBookStats_fields {

    constexpr int book_id = 1;
    constexpr int book_xp = 2;
    constexpr int book_max_xp = 3;

} // namespace CMsgAccountBookStats_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGACCOUNTBOOKSTATS_HPP

