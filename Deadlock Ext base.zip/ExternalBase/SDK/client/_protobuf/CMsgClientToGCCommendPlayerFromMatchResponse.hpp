// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCCommendPlayerFromMatchResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCCOMMENDPLAYERFROMMATCHRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCCOMMENDPLAYERFROMMATCHRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCCommendPlayerFromMatchResponse_fields {

    enum class EResponse : int {
        k_eInternalError = 0,
        k_eSuccess = 1,
        k_eDisabled = 2,
        k_eTooBusy = 3,
        k_eRateLimited = 4,
        k_eTimeout = 5,
    };

    constexpr int result = 1;

} // namespace CMsgClientToGCCommendPlayerFromMatchResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCCOMMENDPLAYERFROMMATCHRESPONSE_HPP

