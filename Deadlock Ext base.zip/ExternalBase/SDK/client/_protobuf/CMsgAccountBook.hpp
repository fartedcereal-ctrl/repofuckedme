// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAccountBook
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGACCOUNTBOOK_HPP
#define SDK_PROTO_CMSGACCOUNTBOOK_HPP

namespace sdk::proto {

struct CMsgAccountBook_Unlock;

namespace CMsgAccountBook_fields {

    namespace Unlock {
        constexpr int unlock_id = 1;
        constexpr int flags = 2;
    } // namespace Unlock

    constexpr int book_id = 1;
    constexpr int book_xp = 2;
    constexpr int spent_xp = 3;
    constexpr int unlocks = 4;

} // namespace CMsgAccountBook_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGACCOUNTBOOK_HPP

