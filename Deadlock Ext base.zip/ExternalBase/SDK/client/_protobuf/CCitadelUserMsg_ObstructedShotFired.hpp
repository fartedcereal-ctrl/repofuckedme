// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_ObstructedShotFired
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_OBSTRUCTEDSHOTFIRED_HPP
#define SDK_PROTO_CCITADELUSERMSG_OBSTRUCTEDSHOTFIRED_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_ObstructedShotFired_fields {


} // namespace CCitadelUserMsg_ObstructedShotFired_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_OBSTRUCTEDSHOTFIRED_HPP

