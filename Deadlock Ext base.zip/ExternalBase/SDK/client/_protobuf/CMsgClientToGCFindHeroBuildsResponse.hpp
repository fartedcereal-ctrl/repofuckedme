// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCFindHeroBuildsResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCFINDHEROBUILDSRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCFINDHEROBUILDSRESPONSE_HPP

namespace sdk::proto {

struct CMsgClientToGCFindHeroBuildsResponse_HeroBuildResult;

namespace CMsgClientToGCFindHeroBuildsResponse_fields {

    enum class EResponse : int {
        k_eInternalError = 0,
        k_eSuccess = 1,
        k_eTooBusy = 2,
    };

    namespace HeroBuildResult {
        constexpr int hero_build = 1;
        constexpr int preference = 2;
        constexpr int num_favorites = 3;
        constexpr int num_ignores = 4;
        constexpr int num_reports = 5;
        constexpr int num_weekly_favorites = 6;
        constexpr int num_daily_favorites = 7;
        constexpr int rollup_category = 8;
    } // namespace HeroBuildResult

    constexpr int response = 1;
    constexpr int results = 2;

} // namespace CMsgClientToGCFindHeroBuildsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCFINDHEROBUILDSRESPONSE_HPP

