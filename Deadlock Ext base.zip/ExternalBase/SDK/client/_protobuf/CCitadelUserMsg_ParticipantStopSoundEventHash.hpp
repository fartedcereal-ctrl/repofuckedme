// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_ParticipantStopSoundEventHash
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSTOPSOUNDEVENTHASH_HPP
#define SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSTOPSOUNDEVENTHASH_HPP

namespace sdk::proto {

struct CMsgSosStopSoundEventHash;

namespace CCitadelUserMsg_ParticipantStopSoundEventHash_fields {

    constexpr int event = 1;
    constexpr int player_slots = 2;

} // namespace CCitadelUserMsg_ParticipantStopSoundEventHash_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSTOPSOUNDEVENTHASH_HPP

