// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAddItemToSocket
// Module: client.dll
// Proto file: base_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGADDITEMTOSOCKET_HPP
#define SDK_PROTO_CMSGADDITEMTOSOCKET_HPP

namespace sdk::proto {

struct CMsgAddItemToSocketData;

namespace CMsgAddItemToSocket_fields {

    constexpr int item_item_id = 1;
    constexpr int gems_to_socket = 2;

} // namespace CMsgAddItemToSocket_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGADDITEMTOSOCKET_HPP

