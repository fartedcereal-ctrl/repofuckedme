// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCAggregateMetrics
// Module: client.dll
// Proto file: base_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCAGGREGATEMETRICS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCAGGREGATEMETRICS_HPP

namespace sdk::proto {

struct CMsgClientToGCAggregateMetrics_SingleMetric;

namespace CMsgClientToGCAggregateMetrics_fields {

    namespace SingleMetric {
        constexpr int metric_name = 1;
        constexpr int metric_count = 2;
    } // namespace SingleMetric

    constexpr int metrics = 1;

} // namespace CMsgClientToGCAggregateMetrics_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCAGGREGATEMETRICS_HPP

