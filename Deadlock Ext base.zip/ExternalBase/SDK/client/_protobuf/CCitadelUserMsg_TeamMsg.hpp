// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_TeamMsg
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_TEAMMSG_HPP
#define SDK_PROTO_CCITADELUSERMSG_TEAMMSG_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_TeamMsg_fields {

    constexpr int event_type = 1;
    constexpr int team_number = 2;
    constexpr int lane_color = 3;
    constexpr int player_controller = 4;

} // namespace CCitadelUserMsg_TeamMsg_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_TEAMMSG_HPP

