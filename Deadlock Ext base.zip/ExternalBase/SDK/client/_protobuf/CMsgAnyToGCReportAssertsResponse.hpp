// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAnyToGCReportAssertsResponse
// Module: client.dll
// Proto file: citadel_gcmessages_common.proto
#pragma once
#ifndef SDK_PROTO_CMSGANYTOGCREPORTASSERTSRESPONSE_HPP
#define SDK_PROTO_CMSGANYTOGCREPORTASSERTSRESPONSE_HPP

namespace sdk::proto {

namespace CMsgAnyToGCReportAssertsResponse_fields {

    constexpr int success = 1;

} // namespace CMsgAnyToGCReportAssertsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGANYTOGCREPORTASSERTSRESPONSE_HPP

