// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGrantForumAccessResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGRANTFORUMACCESSRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGRANTFORUMACCESSRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCGrantForumAccessResponse_fields {

    enum class EResponse : int {
        k_eInternalError = 0,
        k_eSuccess = 1,
        k_eAlreadyClaimed = 2,
        k_eDisabled = 3,
        k_eEmailUsed = 4,
    };

    constexpr int response = 1;
    constexpr int email = 2;
    constexpr int username = 3;
    constexpr int forum_password = 4;

} // namespace CMsgClientToGCGrantForumAccessResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGRANTFORUMACCESSRESPONSE_HPP

