// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_HideoutSpawn
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTSPAWN_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTSPAWN_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_HideoutSpawn_fields {

    constexpr int hero_id = 1;
    constexpr int show_intro = 2;

} // namespace CCitadelClientMsg_HideoutSpawn_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTSPAWN_HPP

