// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAccountHeroStats
// Module: client.dll
// Proto file: citadel_gcmessages_common.proto
#pragma once
#ifndef SDK_PROTO_CMSGACCOUNTHEROSTATS_HPP
#define SDK_PROTO_CMSGACCOUNTHEROSTATS_HPP

namespace sdk::proto {

namespace CMsgAccountHeroStats_fields {

    constexpr int hero_id = 1;
    constexpr int stat_id = 2;
    constexpr int total_value = 3;
    constexpr int medals_bronze = 4;
    constexpr int medals_silver = 5;
    constexpr int medals_gold = 6;

} // namespace CMsgAccountHeroStats_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGACCOUNTHEROSTATS_HPP

