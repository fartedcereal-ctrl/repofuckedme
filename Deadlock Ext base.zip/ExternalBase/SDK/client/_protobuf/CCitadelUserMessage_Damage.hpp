// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMessage_Damage
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMESSAGE_DAMAGE_HPP
#define SDK_PROTO_CCITADELUSERMESSAGE_DAMAGE_HPP

namespace sdk::proto {

struct CMsgVector;

namespace CCitadelUserMessage_Damage_fields {

    constexpr int damage = 1;
    constexpr int pre_damage_deprecated = 2;
    constexpr int pre_damage = 27;
    constexpr int type = 3;
    constexpr int citadel_type = 4;
    constexpr int origin = 5;
    constexpr int entindex_victim = 6;
    constexpr int entindex_inflictor = 7;
    constexpr int entindex_attacker = 8;
    constexpr int entindex_ability = 9;
    constexpr int damage_absorbed_deprecated = 10;
    constexpr int damage_absorbed = 28;
    constexpr int victim_health_max = 11;
    constexpr int victim_health_new = 12;
    constexpr int flags = 13;
    constexpr int ability_id = 14;
    constexpr int attacker_class = 15;
    constexpr int victim_class = 16;
    constexpr int victim_shield_max = 17;
    constexpr int victim_shield_new = 18;
    constexpr int hits = 19;
    constexpr int health_lost = 20;
    constexpr int hitgroup_id = 21;
    constexpr int entindex_attacking_object = 22;
    constexpr int damage_direction = 23;
    constexpr int is_secondary_stat = 24;
    constexpr int effectiveness = 25;
    constexpr int crit_damage = 26;
    constexpr int server_tick = 29;

} // namespace CCitadelUserMessage_Damage_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMESSAGE_DAMAGE_HPP

