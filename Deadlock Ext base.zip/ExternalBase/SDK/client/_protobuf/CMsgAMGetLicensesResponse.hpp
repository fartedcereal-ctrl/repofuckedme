// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAMGetLicensesResponse
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CMSGAMGETLICENSESRESPONSE_HPP
#define SDK_PROTO_CMSGAMGETLICENSESRESPONSE_HPP

namespace sdk::proto {

struct CMsgPackageLicense;

namespace CMsgAMGetLicensesResponse_fields {

    constexpr int license = 1;
    constexpr int result = 2;

} // namespace CMsgAMGetLicensesResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAMGETLICENSESRESPONSE_HPP

