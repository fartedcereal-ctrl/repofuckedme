// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCNameItem
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCNAMEITEM_HPP
#define SDK_PROTO_CMSGCLIENTTOGCNAMEITEM_HPP

namespace sdk::proto {

namespace CMsgClientToGCNameItem_fields {

    constexpr int subject_item_id = 1;
    constexpr int tool_item_id = 2;
    constexpr int name = 3;

} // namespace CMsgClientToGCNameItem_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCNAMEITEM_HPP

