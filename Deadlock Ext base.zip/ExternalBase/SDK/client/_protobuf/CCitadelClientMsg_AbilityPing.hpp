// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_AbilityPing
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_ABILITYPING_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_ABILITYPING_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_AbilityPing_fields {

    constexpr int entity_index = 1;
    constexpr int pinged_ability_id = 2;
    constexpr int pinged_player_slot = 3;

} // namespace CCitadelClientMsg_AbilityPing_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_ABILITYPING_HPP

