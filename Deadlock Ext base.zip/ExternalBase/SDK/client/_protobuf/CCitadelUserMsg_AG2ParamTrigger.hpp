// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_AG2ParamTrigger
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_AG2PARAMTRIGGER_HPP
#define SDK_PROTO_CCITADELUSERMSG_AG2PARAMTRIGGER_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_AG2ParamTrigger_fields {

    constexpr int param_id = 1;
    constexpr int param_value = 2;

} // namespace CCitadelUserMsg_AG2ParamTrigger_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_AG2PARAMTRIGGER_HPP

