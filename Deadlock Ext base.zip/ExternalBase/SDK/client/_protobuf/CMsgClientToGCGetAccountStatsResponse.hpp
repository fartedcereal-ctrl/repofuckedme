// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetAccountStatsResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTSTATSRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTSTATSRESPONSE_HPP

namespace sdk::proto {

struct CMsgAccountStats;

namespace CMsgClientToGCGetAccountStatsResponse_fields {

    enum class EResult : int {
        k_eInternalError = 0,
        k_eSuccess = 1,
        k_eDisabled = 2,
        k_eTooBusy = 3,
        k_eRateLimited = 4,
        k_eInvalidPermissions = 5,
    };

    constexpr int result = 1;
    constexpr int stats = 2;

} // namespace CMsgClientToGCGetAccountStatsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTSTATSRESPONSE_HPP

