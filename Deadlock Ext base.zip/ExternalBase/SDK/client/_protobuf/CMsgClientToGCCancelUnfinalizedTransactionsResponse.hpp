// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCCancelUnfinalizedTransactionsResponse
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCCANCELUNFINALIZEDTRANSACTIONSRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCCANCELUNFINALIZEDTRANSACTIONSRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCCancelUnfinalizedTransactionsResponse_fields {

    constexpr int result = 1;

} // namespace CMsgClientToGCCancelUnfinalizedTransactionsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCCANCELUNFINALIZEDTRANSACTIONSRESPONSE_HPP

