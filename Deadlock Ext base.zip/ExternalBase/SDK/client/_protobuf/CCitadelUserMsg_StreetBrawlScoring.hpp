// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_StreetBrawlScoring
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_STREETBRAWLSCORING_HPP
#define SDK_PROTO_CCITADELUSERMSG_STREETBRAWLSCORING_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_StreetBrawlScoring_fields {

    constexpr int scoring_team = 1;
    constexpr int just_a_test = 2;
    constexpr int sapphire_score = 3;
    constexpr int amber_score = 4;

} // namespace CCitadelUserMsg_StreetBrawlScoring_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_STREETBRAWLSCORING_HPP

