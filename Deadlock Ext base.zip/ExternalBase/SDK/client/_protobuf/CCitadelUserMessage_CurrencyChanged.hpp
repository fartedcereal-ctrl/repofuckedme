// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMessage_CurrencyChanged
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMESSAGE_CURRENCYCHANGED_HPP
#define SDK_PROTO_CCITADELUSERMESSAGE_CURRENCYCHANGED_HPP

namespace sdk::proto {

struct CMsgVector;

namespace CCitadelUserMessage_CurrencyChanged_fields {

    constexpr int userid = 1;
    constexpr int currency_type = 2;
    constexpr int currency_source = 3;
    constexpr int delta = 4;
    constexpr int notification = 5;
    constexpr int entindex_victim = 6;
    constexpr int victim_pos = 7;
    constexpr int playsound = 8;
    constexpr int ability_id = 9;
    constexpr int new_value = 10;

} // namespace CCitadelUserMessage_CurrencyChanged_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMESSAGE_CURRENCYCHANGED_HPP

