// Auto-generated protobuf enums — DO NOT EDIT
// Proto file: citadel_gcmessages_server.proto
// Module: client.dll
#pragma once
#ifndef SDK_PROTO_CITADEL_GCMESSAGES_SERVER_ENUMS_HPP
#define SDK_PROTO_CITADEL_GCMESSAGES_SERVER_ENUMS_HPP

namespace sdk::proto {

enum class EGCCitadelServerMessages : int {
    k_EMsgServerToGCMatchSignoutPermission = 10012,
    k_EMsgServerToGCMatchSignoutPermissionResponse = 10013,
    k_EMsgServerToGCMatchSignout = 10014,
    k_EMsgServerToGCMatchSignoutResponse = 10015,
    k_EMsgGCToServerAddSpectator = 10016,
    k_EMsgGCToServerAddSpectatorResponse = 10017,
    k_EMsgServerToGCIdlePing = 10018,
    k_EMsgGCToServerRequestPing = 10019,
    k_EMsgGCToServerAllocateForMatch = 10021,
    k_EMsgGCToServerAllocateForMatchResponse = 10022,
    k_EMsgServerToGCEnterMatchmaking = 10023,
    k_EMsgGCToServerCancelAllocateForMatch = 10024,
    k_EMsgServerToGCUpdateLobbyServerState = 10025,
    k_EMsgServerToGCAbandonMatch = 10026,
    k_EMsgServerToGCAbandonMatchResponse = 10027,
    k_EMsgServerToGCTestConnection = 10028,
    k_EMsgServerToGCTestConnectionResponse = 10029,
    k_EMsgGCToServerSetServerConVar = 10039,
    k_EMsgGCToServerSetServerConVarResponse = 10040,
    k_EMsgServerToGCUpdateMatchInfo = 10041,
    k_EMsgServerToGCRequestPlayerHeroData = 10044,
    k_EMsgServerToGCRequestPlayerHeroDataResponse = 10045,
    k_EMsgGCToServerAllocateForHideout = 10046,
    k_EMsgGCToServerAllocateForHideoutResponse = 10047,
};

enum class ECitadelMatchAuxStat : int {
    k_eMatchAuxStat_Dummy = 1,
};

enum class EGCServerLobbyData : int {
    k_EServerLobbyData_PlayerMMR = 1,
    k_EServerLobbyData_PlayerInfo = 2,
    k_EServerLobbyData_PostMatchSurvey = 3,
    k_EServerLobbyData_AutoTest = 4,
    k_EServerLobbyData_PlayerStatValues = 5,
};

enum class EGCServerSignoutData : int {
    k_EServerSignoutData_Disconnections = 2,
    k_EServerSignoutData_AccountStatChanges = 3,
    k_EServerSignoutData_DetailedStats = 4,
    k_EServerSignoutData_ServerPerfStats = 5,
    k_EServerSignoutData_PerfData = 6,
    k_EServerSignoutData_PlayerChat = 7,
    k_EServerSignoutData_BookRewards = 8,
    k_EServerSignoutData_PenalizedPlayers = 9,
    k_EServerSignoutData_MatchDevStats = 11,
    k_EServerSignoutData_ChallengeProgress = 12,
    k_EServerSignoutData_HeroXPGrant = 13,
    k_EServerSignoutData_MatchKills = 14,
    k_EServerSignoutData_PlayerBehavior = 15,
    k_EServerSignoutData_StreetBrawlData = 16,
};

} // namespace sdk::proto

#endif // SDK_PROTO_CITADEL_GCMESSAGES_SERVER_ENUMS_HPP

