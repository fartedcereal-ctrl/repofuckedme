// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CClientReconnectInfo
// Module: client.dll
// Proto file: citadel_gamemessages.proto
#pragma once
#ifndef SDK_PROTO_CCLIENTRECONNECTINFO_HPP
#define SDK_PROTO_CCLIENTRECONNECTINFO_HPP

namespace sdk::proto {

namespace CClientReconnectInfo_fields {

    constexpr int server_steam_id = 1;
    constexpr int lobby_id = 2;
    constexpr int time_updated = 3;
    constexpr int udp_connect_ip = 4;
    constexpr int udp_connect_port = 5;
    constexpr int compatibility_version = 6;

} // namespace CClientReconnectInfo_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCLIENTRECONNECTINFO_HPP

