// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelEntityMsg_BreakablePropSpawnDebris
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELENTITYMSG_BREAKABLEPROPSPAWNDEBRIS_HPP
#define SDK_PROTO_CCITADELENTITYMSG_BREAKABLEPROPSPAWNDEBRIS_HPP

namespace sdk::proto {

struct CEntityMsg;
struct CMsgVector;

namespace CCitadelEntityMsg_BreakablePropSpawnDebris_fields {

    constexpr int entity_msg = 1;
    constexpr int damage_pos = 2;
    constexpr int damage = 3;
    constexpr int damage_force = 4;

} // namespace CCitadelEntityMsg_BreakablePropSpawnDebris_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELENTITYMSG_BREAKABLEPROPSPAWNDEBRIS_HPP

