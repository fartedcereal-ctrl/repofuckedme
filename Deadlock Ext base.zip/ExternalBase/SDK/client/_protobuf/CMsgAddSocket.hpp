// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAddSocket
// Module: client.dll
// Proto file: base_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGADDSOCKET_HPP
#define SDK_PROTO_CMSGADDSOCKET_HPP

namespace sdk::proto {

namespace CMsgAddSocket_fields {

    constexpr int tool_item_id = 1;
    constexpr int item_item_id = 2;
    constexpr int unusual = 3;

} // namespace CMsgAddSocket_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGADDSOCKET_HPP

