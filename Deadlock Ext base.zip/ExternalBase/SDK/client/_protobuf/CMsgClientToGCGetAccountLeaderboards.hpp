// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetAccountLeaderboards
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTLEADERBOARDS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTLEADERBOARDS_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetAccountLeaderboards_fields {

    constexpr int account_id = 1;

} // namespace CMsgClientToGCGetAccountLeaderboards_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTLEADERBOARDS_HPP

