// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCFindHeroBuilds
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCFINDHEROBUILDS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCFINDHEROBUILDS_HPP

namespace sdk::proto {

namespace CMsgClientToGCFindHeroBuilds_fields {

    constexpr int author_account_id = 1;
    constexpr int hero_id = 2;
    constexpr int language = 3;
    constexpr int search_text = 4;
    constexpr int hero_build_id = 5;
    constexpr int tags = 6;

} // namespace CMsgClientToGCFindHeroBuilds_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCFINDHEROBUILDS_HPP

