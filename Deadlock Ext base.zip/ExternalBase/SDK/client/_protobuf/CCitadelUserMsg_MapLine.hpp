// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_MapLine
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_MAPLINE_HPP
#define SDK_PROTO_CCITADELUSERMSG_MAPLINE_HPP

namespace sdk::proto {

struct CMsgMapLine;

namespace CCitadelUserMsg_MapLine_fields {

    constexpr int sender_player_slot = 1;
    constexpr int mapline = 2;

} // namespace CCitadelUserMsg_MapLine_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_MAPLINE_HPP

