// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCCommendPlayerFromMatch
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCCOMMENDPLAYERFROMMATCH_HPP
#define SDK_PROTO_CMSGCLIENTTOGCCOMMENDPLAYERFROMMATCH_HPP

namespace sdk::proto {

namespace CMsgClientToGCCommendPlayerFromMatch_fields {

    constexpr int match_id = 1;
    constexpr int target_account_id = 2;
    constexpr int commend_type = 3;
    constexpr int fake_commend_hero_id = 4;

} // namespace CMsgClientToGCCommendPlayerFromMatch_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCCOMMENDPLAYERFROMMATCH_HPP

