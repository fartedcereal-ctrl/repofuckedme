// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgApplyAutograph
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGAPPLYAUTOGRAPH_HPP
#define SDK_PROTO_CMSGAPPLYAUTOGRAPH_HPP

namespace sdk::proto {

namespace CMsgApplyAutograph_fields {

    constexpr int autograph_item_id = 1;
    constexpr int item_item_id = 2;

} // namespace CMsgApplyAutograph_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAPPLYAUTOGRAPH_HPP

