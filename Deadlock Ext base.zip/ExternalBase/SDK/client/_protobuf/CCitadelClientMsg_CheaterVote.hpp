// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_CheaterVote
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_CHEATERVOTE_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_CHEATERVOTE_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_CheaterVote_fields {

    constexpr int end_game_immediately = 1;

} // namespace CCitadelClientMsg_CheaterVote_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_CHEATERVOTE_HPP

