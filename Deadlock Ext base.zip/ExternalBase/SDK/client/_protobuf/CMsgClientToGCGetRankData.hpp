// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetRankData
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETRANKDATA_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETRANKDATA_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetRankData_fields {


} // namespace CMsgClientToGCGetRankData_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETRANKDATA_HPP

