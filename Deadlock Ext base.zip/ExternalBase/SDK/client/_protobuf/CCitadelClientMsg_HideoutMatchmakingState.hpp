// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_HideoutMatchmakingState
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTMATCHMAKINGSTATE_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTMATCHMAKINGSTATE_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_HideoutMatchmakingState_fields {

    constexpr int is_matchmaking = 1;

} // namespace CCitadelClientMsg_HideoutMatchmakingState_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_HIDEOUTMATCHMAKINGSTATE_HPP

