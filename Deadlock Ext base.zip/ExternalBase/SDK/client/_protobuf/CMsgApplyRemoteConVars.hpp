// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgApplyRemoteConVars
// Module: client.dll
// Proto file: base_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGAPPLYREMOTECONVARS_HPP
#define SDK_PROTO_CMSGAPPLYREMOTECONVARS_HPP

namespace sdk::proto {

struct CMsgApplyRemoteConVars_ConVar;

namespace CMsgApplyRemoteConVars_fields {

    namespace ConVar {
        constexpr int name = 1;
        constexpr int value = 2;
        constexpr int version_min = 3;
        constexpr int version_max = 4;
        constexpr int platform = 5;
    } // namespace ConVar

    constexpr int con_vars = 1;

} // namespace CMsgApplyRemoteConVars_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAPPLYREMOTECONVARS_HPP

