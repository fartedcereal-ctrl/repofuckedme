// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGenerateChallengeSetResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGENERATECHALLENGESETRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGENERATECHALLENGESETRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCGenerateChallengeSetResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eInternalError = 1,
        k_eChallengeActive = 2,
        k_eChallengeChoiceExists = 3,
    };

    constexpr int result = 1;

} // namespace CMsgClientToGCGenerateChallengeSetResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGENERATECHALLENGESETRESPONSE_HPP

