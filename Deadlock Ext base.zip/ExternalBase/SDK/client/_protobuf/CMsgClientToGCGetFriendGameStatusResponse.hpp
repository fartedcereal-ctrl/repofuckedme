// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetFriendGameStatusResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETFRIENDGAMESTATUSRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETFRIENDGAMESTATUSRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetFriendGameStatusResponse_fields {

    enum class EResponse : int {
        k_eInternalError = 0,
        k_eSuccess = 1,
        k_eTooBusy = 2,
        k_eDisabled = 3,
    };

    constexpr int response = 1;
    constexpr int friends_played_game = 2;
    constexpr int friends_invited = 3;
    constexpr int friends_invites_sent = 4;

} // namespace CMsgClientToGCGetFriendGameStatusResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETFRIENDGAMESTATUSRESPONSE_HPP

