// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_ChatMsg
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_CHATMSG_HPP
#define SDK_PROTO_CCITADELUSERMSG_CHATMSG_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_ChatMsg_fields {

    constexpr int player_slot = 1;
    constexpr int text = 2;
    constexpr int all_chat = 3;
    constexpr int lane_color = 4;

} // namespace CCitadelUserMsg_ChatMsg_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_CHATMSG_HPP

