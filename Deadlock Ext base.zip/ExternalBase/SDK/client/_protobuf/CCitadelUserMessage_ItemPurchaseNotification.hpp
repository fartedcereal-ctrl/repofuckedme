// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMessage_ItemPurchaseNotification
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMESSAGE_ITEMPURCHASENOTIFICATION_HPP
#define SDK_PROTO_CCITADELUSERMESSAGE_ITEMPURCHASENOTIFICATION_HPP

namespace sdk::proto {

namespace CCitadelUserMessage_ItemPurchaseNotification_fields {

    constexpr int userid = 1;
    constexpr int ability_id = 2;
    constexpr int sell = 3;
    constexpr int quickbuy = 4;

} // namespace CCitadelUserMessage_ItemPurchaseNotification_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMESSAGE_ITEMPURCHASENOTIFICATION_HPP

