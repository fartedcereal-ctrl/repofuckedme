// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_PerformanceStats
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_PERFORMANCESTATS_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_PERFORMANCESTATS_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_PerformanceStats_fields {

    constexpr int current_game_time = 1;
    constexpr int average_fps = 2;
    constexpr int min_fps = 3;
    constexpr int max_fps = 4;

} // namespace CCitadelClientMsg_PerformanceStats_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_PERFORMANCESTATS_HPP

