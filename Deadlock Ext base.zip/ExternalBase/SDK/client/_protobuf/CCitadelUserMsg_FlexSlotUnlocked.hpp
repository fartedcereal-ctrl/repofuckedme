// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_FlexSlotUnlocked
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_FLEXSLOTUNLOCKED_HPP
#define SDK_PROTO_CCITADELUSERMSG_FLEXSLOTUNLOCKED_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_FlexSlotUnlocked_fields {

    constexpr int team_number = 1;
    constexpr int flexslot_unlocked = 2;

} // namespace CCitadelUserMsg_FlexSlotUnlocked_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_FLEXSLOTUNLOCKED_HPP

