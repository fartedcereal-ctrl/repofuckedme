// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CBroadcast_PostGameDataFrame_Request
// Module: client.dll
// Proto file: gcsdk_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CBROADCAST_POSTGAMEDATAFRAME_REQUEST_HPP
#define SDK_PROTO_CBROADCAST_POSTGAMEDATAFRAME_REQUEST_HPP

namespace sdk::proto {

namespace CBroadcast_PostGameDataFrame_Request_fields {

    constexpr int appid = 1;
    constexpr int steamid = 2;
    constexpr int broadcast_id = 3;
    constexpr int frame_data = 4;

} // namespace CBroadcast_PostGameDataFrame_Request_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CBROADCAST_POSTGAMEDATAFRAME_REQUEST_HPP

