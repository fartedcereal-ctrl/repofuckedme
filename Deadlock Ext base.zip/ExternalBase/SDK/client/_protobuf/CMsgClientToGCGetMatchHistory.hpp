// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetMatchHistory
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETMATCHHISTORY_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETMATCHHISTORY_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetMatchHistory_fields {

    constexpr int account_id = 1;
    constexpr int continue_cursor = 2;
    constexpr int game_mode = 4;
    constexpr int match_mode = 5;

} // namespace CMsgClientToGCGetMatchHistory_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETMATCHHISTORY_HPP

