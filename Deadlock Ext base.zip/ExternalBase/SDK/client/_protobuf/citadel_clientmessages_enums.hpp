// Auto-generated protobuf enums — DO NOT EDIT
// Proto file: citadel_clientmessages.proto
// Module: client.dll
#pragma once
#ifndef SDK_PROTO_CITADEL_CLIENTMESSAGES_ENUMS_HPP
#define SDK_PROTO_CITADEL_CLIENTMESSAGES_ENUMS_HPP

namespace sdk::proto {

enum class ECitadelClientMessages : int {
    CITADEL_CM_MapPing = 1002,
    CITADEL_CM_PerformanceStats = 1003,
    CITADEL_CM_PingWheel = 1004,
    CITADEL_CM_ChatMsg = 1005,
    CITADEL_CM_PerfReport = 1006,
    CITADEL_CM_QuickResponse = 1007,
    CITADEL_CM_Pause = 1008,
    CITADEL_CM_MapLine = 1009,
    CITADEL_CM_AbilityPing = 1010,
    CITADEL_CM_ExecuteMapUnitAbility = 1011,
    CITADEL_CM_GetDamageStats = 1012,
    CITADEL_CM_CheaterVote = 1013,
    CITADEL_CM_MutePlayers = 1014,
    CITADEL_CM_HitMismatch = 1015,
    CITADEL_CM_HideoutStart = 1016,
    CITADEL_CM_HeroBuild = 1017,
    CITADEL_CM_HideoutMenuState = 1018,
    CITADEL_CM_HideoutSpawn = 1019,
    CITADEL_CM_HideoutMatchmakingState = 1020,
    CITADEL_CM_PlayerStatsUpdated = 1021,
    CITADEL_CM_HideoutUpdateHeroReleaseVoteTally = 1022,
    CITADEL_CM_ExecuteMapPositionAbility = 1023,
};

} // namespace sdk::proto

#endif // SDK_PROTO_CITADEL_CLIENTMESSAGES_ENUMS_HPP

