// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_PlayerLifetimeStatInfo
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_PLAYERLIFETIMESTATINFO_HPP
#define SDK_PROTO_CCITADELUSERMSG_PLAYERLIFETIMESTATINFO_HPP

namespace sdk::proto {

struct CCitadelUserMsg_PlayerLifetimeStatInfo_Stat;

namespace CCitadelUserMsg_PlayerLifetimeStatInfo_fields {

    namespace Stat {
        constexpr int stat_name = 1;
        constexpr int match_total = 2;
        constexpr int lifetime_value = 3;
        constexpr int priority = 4;
        constexpr int prev_lifetime_max = 5;
        constexpr int stat_type = 6;
        constexpr int stat_type_id = 7;
    } // namespace Stat

    constexpr int stats = 1;
    constexpr int match_id = 2;
    constexpr int end_of_match = 3;
    constexpr int is_official_match = 4;

} // namespace CCitadelUserMsg_PlayerLifetimeStatInfo_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_PLAYERLIFETIMESTATINFO_HPP

