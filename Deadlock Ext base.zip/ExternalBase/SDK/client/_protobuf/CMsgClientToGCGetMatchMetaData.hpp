// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetMatchMetaData
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETMATCHMETADATA_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETMATCHMETADATA_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetMatchMetaData_fields {

    constexpr int match_id = 1;
    constexpr int metadata_salt = 3;
    constexpr int target_account_id = 4;

} // namespace CMsgClientToGCGetMatchMetaData_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETMATCHMETADATA_HPP

