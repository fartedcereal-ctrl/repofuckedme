// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCDevAction
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCDEVACTION_HPP
#define SDK_PROTO_CMSGCLIENTTOGCDEVACTION_HPP

namespace sdk::proto {

namespace CMsgClientToGCDevAction_fields {

    enum class EAction : int {
        k_eSetDeveloper = 1,
        k_eSetMMR = 2,
        k_eSetMMRUncertainty = 3,
        k_eSetHeroStatus = 4,
        k_eSetPermission = 5,
        k_eSetNewPlayerProgress = 6,
        k_eForceAccountStorage = 7,
        k_eBookReset = 9,
        k_eBookXPGrant = 10,
        k_eBanAccount = 11,
        k_eExonerateAccount = 12,
        k_eRequireAccountInMM = 13,
        k_eResetAccountSurvey = 14,
    };

    constexpr int action = 1;
    constexpr int account_id = 2;
    constexpr int uint_value = 3;
    constexpr int int_value = 4;
    constexpr int bool_value = 5;
    constexpr int str_value = 6;
    constexpr int match_id = 7;

} // namespace CMsgClientToGCDevAction_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCDEVACTION_HPP

