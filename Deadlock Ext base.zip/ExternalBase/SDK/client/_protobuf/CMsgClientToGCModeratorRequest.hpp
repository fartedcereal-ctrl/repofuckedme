// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCModeratorRequest
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCMODERATORREQUEST_HPP
#define SDK_PROTO_CMSGCLIENTTOGCMODERATORREQUEST_HPP

namespace sdk::proto {

namespace CMsgClientToGCModeratorRequest_fields {

    constexpr int account_id = 1;

} // namespace CMsgClientToGCModeratorRequest_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCMODERATORREQUEST_HPP

