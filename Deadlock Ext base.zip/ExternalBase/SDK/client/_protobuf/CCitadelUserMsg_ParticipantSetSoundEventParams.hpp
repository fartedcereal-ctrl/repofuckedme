// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_ParticipantSetSoundEventParams
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSETSOUNDEVENTPARAMS_HPP
#define SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSETSOUNDEVENTPARAMS_HPP

namespace sdk::proto {

struct CMsgSosSetSoundEventParams;

namespace CCitadelUserMsg_ParticipantSetSoundEventParams_fields {

    constexpr int event = 1;
    constexpr int player_slots = 2;

} // namespace CCitadelUserMsg_ParticipantSetSoundEventParams_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_PARTICIPANTSETSOUNDEVENTPARAMS_HPP

