// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_GetDamageStatsResponse
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_GETDAMAGESTATSRESPONSE_HPP
#define SDK_PROTO_CCITADELUSERMSG_GETDAMAGESTATSRESPONSE_HPP

namespace sdk::proto {

struct CCitadelUserMsg_GetDamageStatsResponse_StatType;

namespace CCitadelUserMsg_GetDamageStatsResponse_fields {

    namespace StatType {
        constexpr int target_player_slot = 1;
        constexpr int value = 2;
    } // namespace StatType

    constexpr int player_slot = 1;
    constexpr int ability_name = 2;
    constexpr int damage = 3;
    constexpr int healing = 4;

} // namespace CCitadelUserMsg_GetDamageStatsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_GETDAMAGESTATSRESPONSE_HPP

