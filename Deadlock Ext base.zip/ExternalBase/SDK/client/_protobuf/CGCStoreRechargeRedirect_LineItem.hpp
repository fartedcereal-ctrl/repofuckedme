// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCStoreRechargeRedirect_LineItem
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CGCSTORERECHARGEREDIRECT_LINEITEM_HPP
#define SDK_PROTO_CGCSTORERECHARGEREDIRECT_LINEITEM_HPP

namespace sdk::proto {

namespace CGCStoreRechargeRedirect_LineItem_fields {

    constexpr int item_def_id = 1;
    constexpr int quantity = 2;

} // namespace CGCStoreRechargeRedirect_LineItem_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCSTORERECHARGEREDIRECT_LINEITEM_HPP

