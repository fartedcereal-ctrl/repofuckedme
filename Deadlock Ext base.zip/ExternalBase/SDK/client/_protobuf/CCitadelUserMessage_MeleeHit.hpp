// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMessage_MeleeHit
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMESSAGE_MELEEHIT_HPP
#define SDK_PROTO_CCITADELUSERMESSAGE_MELEEHIT_HPP

namespace sdk::proto {

namespace CCitadelUserMessage_MeleeHit_fields {

    constexpr int hit_entindex = 1;
    constexpr int heavy = 2;

} // namespace CCitadelUserMessage_MeleeHit_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMESSAGE_MELEEHIT_HPP

