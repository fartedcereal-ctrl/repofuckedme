// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_RecentDamageSummary
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_RECENTDAMAGESUMMARY_HPP
#define SDK_PROTO_CCITADELUSERMSG_RECENTDAMAGESUMMARY_HPP

namespace sdk::proto {

struct CCitadelUserMsg_RecentDamageSummary_DamageRecord;
struct CCitadelUserMsg_RecentDamageSummary_ModifierRecord;

namespace CCitadelUserMsg_RecentDamageSummary_fields {

    namespace DamageRecord {
        constexpr int damage = 1;
        constexpr int hits = 2;
        constexpr int damage_type = 3;
        constexpr int hero_id = 4;
        constexpr int ability_id = 5;
        constexpr int attacker_class = 6;
        constexpr int damage_absorbed = 7;
        constexpr int is_killing_blow = 8;
        constexpr int victim_hero_id = 9;
        constexpr int is_secondary_stat = 10;
        constexpr int pre_damage = 11;
        constexpr int crit_damage = 12;
    } // namespace DamageRecord

    namespace ModifierRecord {
        constexpr int ability_id = 1;
        constexpr int modifier_type_id = 2;
        constexpr int entindex_caster = 3;
        constexpr int start_time = 4;
        constexpr int end_time = 5;
        constexpr int debuff = 6;
    } // namespace ModifierRecord

    constexpr int player_slot = 1;
    constexpr int damage_records = 2;
    constexpr int start_time = 3;
    constexpr int end_time = 4;
    constexpr int total_damage = 5;
    constexpr int lost_gold = 6;
    constexpr int modifier_records = 7;

} // namespace CCitadelUserMsg_RecentDamageSummary_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_RECENTDAMAGESUMMARY_HPP

