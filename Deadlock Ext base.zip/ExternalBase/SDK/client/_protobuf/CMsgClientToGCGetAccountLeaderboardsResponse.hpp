// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetAccountLeaderboardsResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTLEADERBOARDSRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTLEADERBOARDSRESPONSE_HPP

namespace sdk::proto {

struct CMsgClientToGCGetAccountLeaderboardsResponse_LeaderboardEntry;

namespace CMsgClientToGCGetAccountLeaderboardsResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eInvalidPermission = 1,
        k_eInternalError = 2,
        k_eTooBusy = 3,
    };

    namespace LeaderboardEntry {
        constexpr int region = 1;
        constexpr int hero_id = 2;
        constexpr int rank = 3;
    } // namespace LeaderboardEntry

    constexpr int result = 1;
    constexpr int account_name = 2;
    constexpr int entries = 3;

} // namespace CMsgClientToGCGetAccountLeaderboardsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETACCOUNTLEADERBOARDSRESPONSE_HPP

