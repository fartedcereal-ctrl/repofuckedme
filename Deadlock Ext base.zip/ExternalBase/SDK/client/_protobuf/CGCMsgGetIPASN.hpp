// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgGetIPASN
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGGETIPASN_HPP
#define SDK_PROTO_CGCMSGGETIPASN_HPP

namespace sdk::proto {

namespace CGCMsgGetIPASN_fields {

    constexpr int ips = 1;

} // namespace CGCMsgGetIPASN_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGGETIPASN_HPP

