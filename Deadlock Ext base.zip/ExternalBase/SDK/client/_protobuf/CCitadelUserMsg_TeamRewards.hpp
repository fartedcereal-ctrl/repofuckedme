// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_TeamRewards
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_TEAMREWARDS_HPP
#define SDK_PROTO_CCITADELUSERMSG_TEAMREWARDS_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_TeamRewards_fields {

    constexpr int xp = 1;
    constexpr int gold = 2;
    constexpr int winner = 3;

} // namespace CCitadelUserMsg_TeamRewards_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_TEAMREWARDS_HPP

