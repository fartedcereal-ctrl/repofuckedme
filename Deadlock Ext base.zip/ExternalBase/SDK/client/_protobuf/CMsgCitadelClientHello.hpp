// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgCitadelClientHello
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCITADELCLIENTHELLO_HPP
#define SDK_PROTO_CMSGCITADELCLIENTHELLO_HPP

namespace sdk::proto {

namespace CMsgCitadelClientHello_fields {


} // namespace CMsgCitadelClientHello_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCITADELCLIENTHELLO_HPP

