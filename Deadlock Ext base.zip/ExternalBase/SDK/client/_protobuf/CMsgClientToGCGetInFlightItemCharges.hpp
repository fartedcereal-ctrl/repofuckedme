// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetInFlightItemCharges
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETINFLIGHTITEMCHARGES_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETINFLIGHTITEMCHARGES_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetInFlightItemCharges_fields {

    constexpr int item_def = 1;

} // namespace CMsgClientToGCGetInFlightItemCharges_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETINFLIGHTITEMCHARGES_HPP

