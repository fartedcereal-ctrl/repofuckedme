// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_ChatEvent
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_CHATEVENT_HPP
#define SDK_PROTO_CCITADELUSERMSG_CHATEVENT_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_ChatEvent_fields {

    constexpr int type = 1;
    constexpr int values = 2;
    constexpr int player_slots = 3;

} // namespace CCitadelUserMsg_ChatEvent_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_CHATEVENT_HPP

