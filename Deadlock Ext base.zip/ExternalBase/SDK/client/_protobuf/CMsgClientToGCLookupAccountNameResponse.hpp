// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCLookupAccountNameResponse
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCLOOKUPACCOUNTNAMERESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCLOOKUPACCOUNTNAMERESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCLookupAccountNameResponse_fields {

    constexpr int account_id = 1;
    constexpr int account_name = 2;

} // namespace CMsgClientToGCLookupAccountNameResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCLOOKUPACCOUNTNAMERESPONSE_HPP

