// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetHideoutSDRTicketResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETHIDEOUTSDRTICKETRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETHIDEOUTSDRTICKETRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetHideoutSDRTicketResponse_fields {

    constexpr int ticket = 1;
    constexpr int error_message = 2;

} // namespace CMsgClientToGCGetHideoutSDRTicketResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETHIDEOUTSDRTICKETRESPONSE_HPP

