// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgMemCachedGet
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGMEMCACHEDGET_HPP
#define SDK_PROTO_CGCMSGMEMCACHEDGET_HPP

namespace sdk::proto {

namespace CGCMsgMemCachedGet_fields {

    constexpr int keys = 1;

} // namespace CGCMsgMemCachedGet_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGMEMCACHEDGET_HPP

