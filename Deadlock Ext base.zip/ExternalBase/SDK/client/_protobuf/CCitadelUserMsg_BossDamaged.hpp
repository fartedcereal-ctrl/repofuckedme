// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_BossDamaged
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_BOSSDAMAGED_HPP
#define SDK_PROTO_CCITADELUSERMSG_BOSSDAMAGED_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_BossDamaged_fields {

    constexpr int objective_team = 1;
    constexpr int objective_id = 2;
    constexpr int entity_damaged = 3;

} // namespace CCitadelUserMsg_BossDamaged_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_BOSSDAMAGED_HPP

