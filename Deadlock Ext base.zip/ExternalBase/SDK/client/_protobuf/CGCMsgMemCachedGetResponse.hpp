// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgMemCachedGetResponse
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGMEMCACHEDGETRESPONSE_HPP
#define SDK_PROTO_CGCMSGMEMCACHEDGETRESPONSE_HPP

namespace sdk::proto {

struct CGCMsgMemCachedGetResponse_ValueTag;

namespace CGCMsgMemCachedGetResponse_fields {

    namespace ValueTag {
        constexpr int found = 1;
        constexpr int value = 2;
    } // namespace ValueTag

    constexpr int values = 1;

} // namespace CGCMsgMemCachedGetResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGMEMCACHEDGETRESPONSE_HPP

