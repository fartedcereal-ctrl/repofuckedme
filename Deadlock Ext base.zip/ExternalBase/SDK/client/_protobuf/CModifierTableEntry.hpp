// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CModifierTableEntry
// Module: client.dll
// Proto file: base_modifier.proto
#pragma once
#ifndef SDK_PROTO_CMODIFIERTABLEENTRY_HPP
#define SDK_PROTO_CMODIFIERTABLEENTRY_HPP

namespace sdk::proto {

struct CMsgVector;

namespace CModifierTableEntry_fields {

    constexpr int entry_type = 1;
    constexpr int parent = 2;
    constexpr int serial_number = 3;
    constexpr int modifier_subclass = 4;
    constexpr int stack_count = 5;
    constexpr int max_stack_count = 6;
    constexpr int last_applied_time = 7;
    constexpr int duration = 8;
    constexpr int caster = 9;
    constexpr int ability = 10;
    constexpr int aura_provider_serial_number = 11;
    constexpr int aura_provider_ehandle = 12;
    constexpr int ability_subclass = 13;
    constexpr int in_aura_range = 14;
    constexpr int bool1_ = 20;
    constexpr int bool2_ = 21;
    constexpr int bool3_ = 22;
    constexpr int bool4_ = 23;
    constexpr int int1_ = 25;
    constexpr int int2_ = 26;
    constexpr int int3_ = 27;
    constexpr int int4_ = 28;
    constexpr int float1_ = 30;
    constexpr int float2_ = 31;
    constexpr int float3_ = 32;
    constexpr int float4_ = 33;
    constexpr int float5_ = 49;
    constexpr int float6_ = 50;
    constexpr int float7_ = 51;
    constexpr int float8_ = 52;
    constexpr int float9_ = 53;
    constexpr int float10_ = 54;
    constexpr int float11_ = 55;
    constexpr int float12_ = 56;
    constexpr int float13_ = 57;
    constexpr int float14_ = 58;
    constexpr int float15_ = 59;
    constexpr int float16_ = 60;
    constexpr int uint1_ = 35;
    constexpr int uint2_ = 36;
    constexpr int uint3_ = 37;
    constexpr int uint4_ = 38;
    constexpr int vec1_ = 40;
    constexpr int vec2_ = 41;
    constexpr int vec3_ = 42;
    constexpr int vec4_ = 43;
    constexpr int string1_ = 45;
    constexpr int string2_ = 46;
    constexpr int string3_ = 47;
    constexpr int string4_ = 48;

} // namespace CModifierTableEntry_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMODIFIERTABLEENTRY_HPP

