// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_PingWheel
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_PINGWHEEL_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_PINGWHEEL_HPP

namespace sdk::proto {

struct CMsgVector;

namespace CCitadelClientMsg_PingWheel_fields {

    constexpr int ping_wheel_option_id = 1;
    constexpr int subnav_message_id = 2;
    constexpr int ping_location = 3;
    constexpr int entity_index = 4;

} // namespace CCitadelClientMsg_PingWheel_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_PINGWHEEL_HPP

