// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCMsgSQLStatsResponse
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CGCMSGSQLSTATSRESPONSE_HPP
#define SDK_PROTO_CGCMSGSQLSTATSRESPONSE_HPP

namespace sdk::proto {

namespace CGCMsgSQLStatsResponse_fields {

    constexpr int threads = 1;
    constexpr int threads_connected = 2;
    constexpr int threads_active = 3;
    constexpr int operations_submitted = 4;
    constexpr int prepared_statements_executed = 5;
    constexpr int non_prepared_statements_executed = 6;
    constexpr int deadlock_retries = 7;
    constexpr int operations_timed_out_in_queue = 8;
    constexpr int errors = 9;

} // namespace CGCMsgSQLStatsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCMSGSQLSTATSRESPONSE_HPP

