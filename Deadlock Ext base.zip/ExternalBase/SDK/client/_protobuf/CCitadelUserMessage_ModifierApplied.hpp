// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMessage_ModifierApplied
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMESSAGE_MODIFIERAPPLIED_HPP
#define SDK_PROTO_CCITADELUSERMESSAGE_MODIFIERAPPLIED_HPP

namespace sdk::proto {

namespace CCitadelUserMessage_ModifierApplied_fields {

    constexpr int entindex_caster = 1;
    constexpr int entindex_parent = 2;
    constexpr int serial_number = 3;

} // namespace CCitadelUserMessage_ModifierApplied_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMESSAGE_MODIFIERAPPLIED_HPP

