// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAMGrantGuestPasses2
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CMSGAMGRANTGUESTPASSES2_HPP
#define SDK_PROTO_CMSGAMGRANTGUESTPASSES2_HPP

namespace sdk::proto {

namespace CMsgAMGrantGuestPasses2_fields {

    constexpr int steam_id = 1;
    constexpr int package_id = 2;
    constexpr int passes_to_grant = 3;
    constexpr int days_to_expiration = 4;
    constexpr int action = 5;

} // namespace CMsgAMGrantGuestPasses2_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAMGRANTGUESTPASSES2_HPP

