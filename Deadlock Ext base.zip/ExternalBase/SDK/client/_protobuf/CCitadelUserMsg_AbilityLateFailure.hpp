// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_AbilityLateFailure
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_ABILITYLATEFAILURE_HPP
#define SDK_PROTO_CCITADELUSERMSG_ABILITYLATEFAILURE_HPP

namespace sdk::proto {

namespace CCitadelUserMsg_AbilityLateFailure_fields {

    constexpr int entindex_caster = 1;
    constexpr int entindex_ability = 2;
    constexpr int failure_type = 3;

} // namespace CCitadelUserMsg_AbilityLateFailure_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_ABILITYLATEFAILURE_HPP

