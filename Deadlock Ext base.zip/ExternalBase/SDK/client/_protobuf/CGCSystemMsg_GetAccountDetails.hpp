// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCSystemMsg_GetAccountDetails
// Module: client.dll
// Proto file: steammessages.proto
#pragma once
#ifndef SDK_PROTO_CGCSYSTEMMSG_GETACCOUNTDETAILS_HPP
#define SDK_PROTO_CGCSYSTEMMSG_GETACCOUNTDETAILS_HPP

namespace sdk::proto {

namespace CGCSystemMsg_GetAccountDetails_fields {

    constexpr int steamid = 1;
    constexpr int appid = 2;

} // namespace CGCSystemMsg_GetAccountDetails_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCSYSTEMMSG_GETACCOUNTDETAILS_HPP

