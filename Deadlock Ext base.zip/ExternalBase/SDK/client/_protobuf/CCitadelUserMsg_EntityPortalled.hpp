// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_EntityPortalled
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_ENTITYPORTALLED_HPP
#define SDK_PROTO_CCITADELUSERMSG_ENTITYPORTALLED_HPP

namespace sdk::proto {

struct CMsgTransform;

namespace CCitadelUserMsg_EntityPortalled_fields {

    constexpr int entity_portalled = 1;
    constexpr int portal_transform = 2;

} // namespace CCitadelUserMsg_EntityPortalled_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_ENTITYPORTALLED_HPP

