// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCDevActionResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCDEVACTIONRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCDEVACTIONRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCDevActionResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eInvalidPermission = 1,
        k_eInvalidTarget = 2,
        k_eInternalError = 3,
    };

    constexpr int result = 1;

} // namespace CMsgClientToGCDevActionResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCDEVACTIONRESPONSE_HPP

