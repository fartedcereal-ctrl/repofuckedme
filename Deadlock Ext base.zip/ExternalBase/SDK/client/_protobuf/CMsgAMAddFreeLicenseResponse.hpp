// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgAMAddFreeLicenseResponse
// Module: client.dll
// Proto file: steammessages_int.proto
#pragma once
#ifndef SDK_PROTO_CMSGAMADDFREELICENSERESPONSE_HPP
#define SDK_PROTO_CMSGAMADDFREELICENSERESPONSE_HPP

namespace sdk::proto {

namespace CMsgAMAddFreeLicenseResponse_fields {

    constexpr int eresult = 1;
    constexpr int purchase_result_detail = 2;
    constexpr int transid = 3;

} // namespace CMsgAMAddFreeLicenseResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGAMADDFREELICENSERESPONSE_HPP

