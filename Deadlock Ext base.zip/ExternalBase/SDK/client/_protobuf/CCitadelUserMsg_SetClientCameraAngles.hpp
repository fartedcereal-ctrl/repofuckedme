// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_SetClientCameraAngles
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_SETCLIENTCAMERAANGLES_HPP
#define SDK_PROTO_CCITADELUSERMSG_SETCLIENTCAMERAANGLES_HPP

namespace sdk::proto {

struct CMsgQAngle;

namespace CCitadelUserMsg_SetClientCameraAngles_fields {

    constexpr int player_slot = 1;
    constexpr int camera_angles = 2;

} // namespace CCitadelUserMsg_SetClientCameraAngles_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_SETCLIENTCAMERAANGLES_HPP

