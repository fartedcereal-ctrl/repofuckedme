// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCDeleteHeroBuildResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCDELETEHEROBUILDRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCDELETEHEROBUILDRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCDeleteHeroBuildResponse_fields {

    enum class EResponse : int {
        k_eInternalError = 0,
        k_eSuccess = 1,
    };

    constexpr int response = 1;
    constexpr int builds_deleted = 2;

} // namespace CMsgClientToGCDeleteHeroBuildResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCDELETEHEROBUILDRESPONSE_HPP

