// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_MutePlayers
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_MUTEPLAYERS_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_MUTEPLAYERS_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_MutePlayers_fields {

    constexpr int player_slots = 1;
    constexpr int unmute = 2;

} // namespace CCitadelClientMsg_MutePlayers_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_MUTEPLAYERS_HPP

