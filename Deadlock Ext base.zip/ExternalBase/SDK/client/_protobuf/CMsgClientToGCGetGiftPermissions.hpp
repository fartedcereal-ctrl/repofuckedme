// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCGetGiftPermissions
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCGETGIFTPERMISSIONS_HPP
#define SDK_PROTO_CMSGCLIENTTOGCGETGIFTPERMISSIONS_HPP

namespace sdk::proto {

namespace CMsgClientToGCGetGiftPermissions_fields {


} // namespace CMsgClientToGCGetGiftPermissions_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCGETGIFTPERMISSIONS_HPP

