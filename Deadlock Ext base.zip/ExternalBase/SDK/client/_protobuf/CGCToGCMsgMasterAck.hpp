// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CGCToGCMsgMasterAck
// Module: client.dll
// Proto file: gcsdk_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CGCTOGCMSGMASTERACK_HPP
#define SDK_PROTO_CGCTOGCMSGMASTERACK_HPP

namespace sdk::proto {

struct CGCToGCMsgMasterAck_Process;

namespace CGCToGCMsgMasterAck_fields {

    namespace Process {
        constexpr int dir_index = 1;
        constexpr int type_instances = 2;
    } // namespace Process

    constexpr int dir_index = 1;
    constexpr int machine_name = 3;
    constexpr int process_name = 4;
    constexpr int directory = 6;

} // namespace CGCToGCMsgMasterAck_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CGCTOGCMSGMASTERACK_HPP

