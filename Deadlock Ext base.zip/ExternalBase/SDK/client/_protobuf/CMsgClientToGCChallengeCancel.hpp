// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCChallengeCancel
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCCHALLENGECANCEL_HPP
#define SDK_PROTO_CMSGCLIENTTOGCCHALLENGECANCEL_HPP

namespace sdk::proto {

namespace CMsgClientToGCChallengeCancel_fields {

    constexpr int challenge_id = 1;

} // namespace CMsgClientToGCChallengeCancel_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCCHALLENGECANCEL_HPP

