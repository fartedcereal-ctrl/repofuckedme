// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_PlayerStatsUpdated
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_PLAYERSTATSUPDATED_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_PLAYERSTATSUPDATED_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_PlayerStatsUpdated_fields {


} // namespace CCitadelClientMsg_PlayerStatsUpdated_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_PLAYERSTATSUPDATED_HPP

