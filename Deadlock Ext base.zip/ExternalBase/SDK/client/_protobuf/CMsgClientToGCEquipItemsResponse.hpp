// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCEquipItemsResponse
// Module: client.dll
// Proto file: econ_gcmessages.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCEQUIPITEMSRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCEQUIPITEMSRESPONSE_HPP

namespace sdk::proto {

namespace CMsgClientToGCEquipItemsResponse_fields {

    constexpr int so_cache_version_id = 1;

} // namespace CMsgClientToGCEquipItemsResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCEQUIPITEMSRESPONSE_HPP

