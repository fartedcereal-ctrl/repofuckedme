// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelUserMsg_PingWheel
// Module: client.dll
// Proto file: citadel_usermessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELUSERMSG_PINGWHEEL_HPP
#define SDK_PROTO_CCITADELUSERMSG_PINGWHEEL_HPP

namespace sdk::proto {

struct PingCommonData;

namespace CCitadelUserMsg_PingWheel_fields {

    constexpr int ping_data = 1;
    constexpr int ping_wheel_option_id = 2;

} // namespace CCitadelUserMsg_PingWheel_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELUSERMSG_PINGWHEEL_HPP

