// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CMsgClientToGCBookUnlockResponse
// Module: client.dll
// Proto file: citadel_gcmessages_client.proto
#pragma once
#ifndef SDK_PROTO_CMSGCLIENTTOGCBOOKUNLOCKRESPONSE_HPP
#define SDK_PROTO_CMSGCLIENTTOGCBOOKUNLOCKRESPONSE_HPP

namespace sdk::proto {

struct CMsgAccountBook;

namespace CMsgClientToGCBookUnlockResponse_fields {

    enum class EResult : int {
        k_eSuccess = 0,
        k_eInternalError = 1,
        k_eOutOfDateClient = 2,
        k_eInvalidFunds = 3,
        k_eDisabled = 4,
        k_eTooBusy = 5,
        k_eAlreadyUnlocked = 6,
    };

    constexpr int result = 1;
    constexpr int updated_book = 2;

} // namespace CMsgClientToGCBookUnlockResponse_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CMSGCLIENTTOGCBOOKUNLOCKRESPONSE_HPP

