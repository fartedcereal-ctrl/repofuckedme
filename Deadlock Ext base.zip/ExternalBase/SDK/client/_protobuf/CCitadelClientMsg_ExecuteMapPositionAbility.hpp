// Auto-generated protobuf field constants — DO NOT EDIT
// Message: CCitadelClientMsg_ExecuteMapPositionAbility
// Module: client.dll
// Proto file: citadel_clientmessages.proto
#pragma once
#ifndef SDK_PROTO_CCITADELCLIENTMSG_EXECUTEMAPPOSITIONABILITY_HPP
#define SDK_PROTO_CCITADELCLIENTMSG_EXECUTEMAPPOSITIONABILITY_HPP

namespace sdk::proto {

namespace CCitadelClientMsg_ExecuteMapPositionAbility_fields {

    constexpr int ability_entity_index = 1;
    constexpr int pos_x = 2;
    constexpr int pos_y = 3;
    constexpr int pos_z = 4;

} // namespace CCitadelClientMsg_ExecuteMapPositionAbility_fields

} // namespace sdk::proto

#endif // SDK_PROTO_CCITADELCLIENTMSG_EXECUTEMAPPOSITIONABILITY_HPP

