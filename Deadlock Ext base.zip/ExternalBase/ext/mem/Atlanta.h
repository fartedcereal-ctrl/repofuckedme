#ifndef ATLANTA_H
#define ATLANTA_H

#include <windows.h>
#include <iostream>
#include <vector>
#include <TlHelp32.h>
#include <winternl.h>
#include <string>

#pragma comment(lib, "ntdll.lib")

namespace Atlanta {

    typedef struct _CLIENT_ID {
        HANDLE UniqueProcess;
        HANDLE UniqueThread;
    } CLIENT_ID, * PCLIENT_ID;

    using _NtOpenProcess = NTSTATUS(NTAPI*)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PCLIENT_ID);
    using _NtReadVirtualMemory = NTSTATUS(NTAPI*)(HANDLE, PVOID, PVOID, ULONG, PULONG);
    using _NtWriteVirtualMemory = NTSTATUS(NTAPI*)(HANDLE, PVOID, PVOID, ULONG, PULONG);

#ifdef _DEBUG
#define LOG(x) std::cerr << x
#else
#define LOG(x)
#endif

    inline bool ReadMemory(HANDLE hProcess, uintptr_t address, void* buffer, size_t size) {
        static _NtReadVirtualMemory NtReadVirtualMemoryPtr = (_NtReadVirtualMemory)GetProcAddress(GetModuleHandleA("ntdll.dll"), "NtReadVirtualMemory");
        if (NtReadVirtualMemoryPtr) {
            ULONG bytesRead = 0;
            NTSTATUS status = NtReadVirtualMemoryPtr(hProcess, (PVOID)address, buffer, (ULONG)size, &bytesRead);
            if (status == 0 && bytesRead == size)
                return true;
        }
        return ReadProcessMemory(hProcess, (LPCVOID)address, buffer, size, nullptr);
    }

    inline bool WriteMemory(HANDLE hProcess, uintptr_t address, const void* buffer, size_t size) {
        static _NtWriteVirtualMemory NtWriteVirtualMemoryPtr = (_NtWriteVirtualMemory)GetProcAddress(GetModuleHandleA("ntdll.dll"), "NtWriteVirtualMemory");
        if (NtWriteVirtualMemoryPtr) {
            ULONG bytesWritten = 0;
            NTSTATUS status = NtWriteVirtualMemoryPtr(hProcess, (PVOID)address, (PVOID)buffer, (ULONG)size, &bytesWritten);
            if (status == 0 && bytesWritten == size)
                return true;
        }
        return WriteProcessMemory(hProcess, (LPVOID)address, buffer, size, nullptr);
    }

    inline DWORD GetProcessID(const std::string& processName) {
        DWORD processID = 0;
        HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnapshot != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32 processEntry = { 0 };
            processEntry.dwSize = sizeof(PROCESSENTRY32);
            if (Process32First(hSnapshot, &processEntry)) {
                do {
                    if (!_stricmp(processEntry.szExeFile, processName.c_str())) {
                        processID = processEntry.th32ProcessID;
                        break;
                    }
                } while (Process32Next(hSnapshot, &processEntry));
            }
            CloseHandle(hSnapshot);
        }
        return processID;
    }

    inline HANDLE GetHandle(DWORD processID) {
        HANDLE hProcess = nullptr;
        _NtOpenProcess NtOpenProcess = (_NtOpenProcess)GetProcAddress(GetModuleHandleA("ntdll.dll"), "NtOpenProcess");
        if (NtOpenProcess) {
            CLIENT_ID cid = { (HANDLE)processID, 0 };
            OBJECT_ATTRIBUTES objAttr;
            InitializeObjectAttributes(&objAttr, nullptr, 0, nullptr, nullptr);
            NTSTATUS status = NtOpenProcess(&hProcess, PROCESS_ALL_ACCESS, &objAttr, &cid);
            if (status != 0)
                LOG("NtOpenProcess failed! Status: " << std::hex << status << std::endl);
        }
        else {
            LOG("Failed to get NtOpenProcess address!" << std::endl);
        }
        return hProcess;
    }

    inline DWORD_PTR GetModuleBaseAddress(DWORD processID, const char* moduleName) {
        DWORD_PTR baseAddress = 0;
        HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, processID);
        if (hSnapshot != INVALID_HANDLE_VALUE) {
            MODULEENTRY32 moduleEntry = { 0 };
            moduleEntry.dwSize = sizeof(MODULEENTRY32);
            if (Module32First(hSnapshot, &moduleEntry)) {
                do {
                    if (!_stricmp(moduleEntry.szModule, moduleName)) {
                        baseAddress = (DWORD_PTR)moduleEntry.modBaseAddr;
                        break;
                    }
                } while (Module32Next(hSnapshot, &moduleEntry));
            }
            CloseHandle(hSnapshot);
        }
        return baseAddress;
    }

    inline uintptr_t ResolvePointerChain(HANDLE hProcess, uintptr_t baseAddress, const std::vector<uintptr_t>& offsets) {
        uintptr_t address = baseAddress;
        for (size_t i = 0; i < offsets.size(); i++) {
            if (address < 0x10000 || address > 0x7FFFFFFFFFFF) {
                LOG("Invalid address encountered during pointer chain resolution!" << std::endl);
                return 0;
            }
            uintptr_t tempAddress = 0;
            if (!ReadMemory(hProcess, address, &tempAddress, sizeof(tempAddress))) {
                LOG("ReadMemory failed during pointer resolution! Error: " << GetLastError() << std::endl);
                return 0;
            }
            address = tempAddress + offsets[i];
        }
        return address;
    }

    inline bool WriteBytes(HANDLE hProcess, uintptr_t address, const std::vector<BYTE>& bytes) {
        DWORD oldProtect;
        MEMORY_BASIC_INFORMATION mbi;
        if (VirtualQueryEx(hProcess, (LPCVOID)address, &mbi, sizeof(mbi))) {
            if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) {
                if (!VirtualProtectEx(hProcess, (LPVOID)address, bytes.size(), PAGE_READWRITE, &oldProtect))
                    return false;
            }
        }
        return WriteMemory(hProcess, address, bytes.data(), bytes.size());
    }

    inline std::vector<BYTE> ReadBytes(HANDLE hProcess, uintptr_t address, size_t length) {
        std::vector<BYTE> buffer(length);
        DWORD oldProtect;
        MEMORY_BASIC_INFORMATION mbi;
        if (VirtualQueryEx(hProcess, (LPCVOID)address, &mbi, sizeof(mbi))) {
            if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) {
                if (!VirtualProtectEx(hProcess, (LPVOID)address, length, PAGE_READWRITE, &oldProtect))
                    return {};
            }
        }
        if (!ReadMemory(hProcess, address, buffer.data(), length))
            buffer.clear();
        return buffer;
    }

    inline bool NopAddress(HANDLE hProcess, uintptr_t address, size_t length) {
        std::vector<BYTE> nopBytes(length, 0x90);
        return WriteBytes(hProcess, address, nopBytes);
    }

    template <typename T>
    inline bool Write(HANDLE hProcess, uintptr_t address, T value) {
        DWORD oldProtect;
        MEMORY_BASIC_INFORMATION mbi;
        if (VirtualQueryEx(hProcess, (LPCVOID)address, &mbi, sizeof(mbi))) {
            if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) {
                if (!VirtualProtectEx(hProcess, (LPVOID)address, sizeof(T), PAGE_READWRITE, &oldProtect))
                    return false;
            }
        }
        return WriteMemory(hProcess, address, &value, sizeof(T));
    }

    template <typename T>
    inline T Read(HANDLE hProcess, uintptr_t address) {
        T buffer{};
        ReadMemory(hProcess, address, &buffer, sizeof(T));
        return buffer;
    }

}

#endif