﻿#pragma once
#include <cstdint>

#include <iostream>

namespace FNV1A
{
    constexpr std::uint64_t BASIS = 0xCBF29CE484222325ULL;
    constexpr std::uint64_t PRIME = 0x100000001B3ULL;

    constexpr std::uint64_t HashConst(const char* str, std::uint64_t hash = BASIS)
    {
        return (*str)
            ? HashConst(str + 1, (hash ^ static_cast<std::uint64_t>(*str)) * PRIME)
            : hash;
    }
}

namespace Schema
{
    bool Setup();
    std::uint32_t GetOffset(std::uint64_t hash);
}

#define SCHEMA_FIELD(CLASS, FIELD) CLASS "->" FIELD

#define SCHEMA(TYPE, NAME, CLASS, FIELD)                                      \
    __forceinline TYPE& NAME()                                                 \
    {                                                                          \
        static const std::uint32_t offset =                                    \
            Schema::GetOffset(FNV1A::HashConst(SCHEMA_FIELD(CLASS, FIELD)));   \
                                                                               \
        return *reinterpret_cast<TYPE*>(                                       \
            reinterpret_cast<std::uintptr_t>(this) + offset);                  \
    }

#define SCHEMA_REF(TYPE, NAME, CLASS, FIELD, ADDITIONAL)                       \
    __forceinline TYPE& NAME()                                                 \
    {                                                                          \
        static const std::uint32_t offset =                                    \
            Schema::GetOffset(FNV1A::HashConst(SCHEMA_FIELD(CLASS, FIELD)))    \
            + ADDITIONAL;                                                      \
                                                                               \
        return *reinterpret_cast<TYPE*>(                                       \
            reinterpret_cast<std::uintptr_t>(this) + offset);                  \
    }