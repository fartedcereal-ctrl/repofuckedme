﻿#include "includes.h"
#include "inventory_p.h"
#include "skins.h"
void Unload() {
	SDK::shouldUnload = true;
	
	Sleep(100);
	Events->Destroy();
	S::Shutdown();
	H::Destroy();
	
	logger::shutdown();
	
	kiero::shutdown();
	
	
	FreeLibraryAndExitThread(g_hModule, 0);
}
DWORD WINAPI MainThread(LPVOID lpReserved)
{
#ifdef _DEBUG
	logger::initialize();
#endif
	bool init_hook = false;
	bool modules_loaded = false;

	while (GetModuleHandle(L"matchmaking.dll") == nullptr) {

	}
	while (!modules_loaded) {
		if (!I::initialize()) {
			// Initialization failed
		}
		if (!H::Setup()) {
			// Hook setup failed
		}

		if (!Schema::Setup()) {
			// Schema setup failed
		}

		modules_loaded = true;
	}
	do {
		if (kiero::init(kiero::RenderType::D3D11) == kiero::Status::Success)
		{
			kiero::bind(8, (void**)&oPresent, hkPresent);
			kiero::bind(13, (void**)&oResizeBuffers, hkResizeBuffers);
			init_hook = true;
		}
	} while (!init_hook);
	static bool added = false;

	while (!SDK::shouldUnload) {
		Sleep(500);
		if (!Events->inited) {
			Events->Intilization();
		}
		//if (InventoryPersistence::init() && !added) {
		//	int restored = InventoryPersistence::LoadAndRecreate("added_items.json");
		//	if (restored > 0) {
		//		added = true;
		//		InventoryPersistence::Equip();
		//
		//	}
		//}

		INVENTORY::Dump();
	}

	Unload();
	return TRUE;
}

BOOL WINAPI DllMain(HMODULE hMod, DWORD dwReason, LPVOID lpReserved)
{
	switch (dwReason)
	{
	case DLL_PROCESS_ATTACH:
		g_hModule = hMod;
		DisableThreadLibraryCalls(hMod);
		CreateThread(nullptr, 0, MainThread, hMod, 0, nullptr);
		break;
	case DLL_PROCESS_DETACH:
		if (!SDK::shouldUnload) {
			Unload();
		}
		break;
	}
	return TRUE;
}