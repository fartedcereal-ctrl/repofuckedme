﻿#include "schema.h"
#include "interfaces.h"

#include <vector>
#include <string>
#include <cstdio>

#include <unordered_map>

struct SchemaData_t
{
    std::uint64_t hash;
    std::uint32_t offset;
};

static std::unordered_map<std::uint64_t, std::uint32_t> g_SchemaData;

bool Schema::Setup()
{
    CSchemaSystemTypeScope* pClientTypeScope =
        I::schema->FindTypeScopeForModule("client.dll");

    if (!pClientTypeScope)
        return false;

    for (uint16_t c = 0; c < pClientTypeScope->declared_classes_num; ++c)
    {
        declared_class_entry& entry =
            pClientTypeScope->declaredClasses[c];

        declared_class* pDeclaredClassInfo =
            entry.declared_classes;

        if (!pDeclaredClassInfo || !pDeclaredClassInfo->schema_class)
            continue;

        const char* class_name =
            pDeclaredClassInfo->schema_class->name;

        if (!class_name)
            continue;

        schema_field* fields =
            pDeclaredClassInfo->schema_class->fields;

        uint16_t fields_count =
            pDeclaredClassInfo->schema_class->fields_num;

        if (!fields)
            continue;

        for (uint16_t f = 0; f < fields_count; ++f)
        {
            const char* field_name = fields[f].name;
            if (!field_name)
                continue;

            std::string fullName =
                std::string(class_name) + "->" + field_name;

            std::uint64_t hash =
                FNV1A::HashConst(fullName.c_str());

            g_SchemaData.emplace(hash, fields[f].offset);
        }
    }

    return true;
}

std::uint32_t Schema::GetOffset(std::uint64_t hash)
{
    auto it = g_SchemaData.find(hash);
    if (it != g_SchemaData.end())
        return it->second;

    return 0U;
}